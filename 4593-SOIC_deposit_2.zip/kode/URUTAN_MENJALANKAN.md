# Run order

Notebooks and plain-Python exports of the same code are both provided; use
whichever suits your environment. The notebooks were run on Google Colab.

1. `revisi_soic_BASELINE_UTAMA.py`
   Fits the simpler comparators (logistic regression, linear SVM, random
   forest) under the primary protocol and writes `baseline_utama_*.csv`.

2. `REVISI_SOIC_7817.ipynb`  (export: `revisi_soic_7817.py`)
   The main pipeline: curation to 7,817 structures, both representations,
   three repetitions of five-fold scaffold cross-validation, calibration,
   endpoint thresholds, ensemble, ablation and imbalance variants,
   significance testing, application to the 31 compounds, applicability
   domain, ranking stability. Reuses the baseline files from step 1.
   Input: `data/ini_saja.xlsx`. Writes every file in `hasil/`.
   Its final cell runs the consistency audit; every row must read True.

3. `BUAT_4_GAMBAR_SISA.ipynb`  (export: `buat_4_gambar_sisa.py`)
   Figures 3, 4, 6 and 7, from the cross-validation checkpoint.
   Prints the panel mean ROC-AUC as a check; it must read 0.7929.

4. `roadmap.py`
   Figure 1.

TODO: add the scripts for Figures 2, 5, 8, 9, 10, 11, 12 and 13.

All notebooks are stored with their outputs cleared.
