# =============================================================================
# EMPAT GAMBAR SISA UNTUK NASKAH REVISI 4593-SOIC
#
# Jalankan sebagai SATU SEL di notebook Colab yang sama dengan pipeline.
# Tidak ada pelatihan ulang: seluruhnya dibaca dari checkpoint s3_cv yang
# sudah ada. Perkiraan waktu < 2 menit.
#
# Luaran, di BASE/hasil/figures/ :
#   Endpoint Specific2.png                        kurva ROC per titik akhir
#   Endpoint Specific3.png                        kurva presisi-recall
#   08_calibration_curves.png                     kurva keterandalan
#   10_ensemble_roc_auc_confidence_intervals.png  ROC-AUC + selang bootstrap
#   oof_ensemble.csv.gz                           probabilitas OOF ensemble
#
# Unduh kelima berkas itu, taruh keempat PNG di folder naskah (menimpa yang
# lama), lalu kompilasi ulang.
# =============================================================================

from pathlib import Path
import pickle, numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score, precision_recall_curve

# ----------------------------------------------------------------- lokasi ---
BASE = Path("/content/drive/MyDrive/revisi_soic")
if not BASE.exists():
    BASE = Path("/content/revisi_soic")
    if not BASE.exists():
        BASE = Path("./revisi_soic")
CKPT, FIG = BASE / "checkpoints", BASE / "hasil" / "figures"
FIG.mkdir(parents=True, exist_ok=True)
print("BASE :", BASE)

TOX21_TASKS = ["NR-AR", "NR-AR-LBD", "NR-AhR", "NR-Aromatase", "NR-ER",
               "NR-ER-LBD", "NR-PPAR-gamma", "SR-ARE", "SR-ATAD5", "SR-HSE",
               "SR-MMP", "SR-p53"]


def _load(nama):
    p = CKPT / f"{nama}.pkl"
    return pickle.load(open(p, "rb")) if p.exists() else None


# --------------------------------------------------- ambil probabilitas OOF -
s3 = _load("s3_cv")
if s3 is not None:
    oof = s3["oof"]
    print("Sumber: s3_cv.pkl")
else:                                   # cadangan: rakit dari s3_ep*.pkl
    bagian = [_load(f"s3_ep{i:02d}") for i in range(len(TOX21_TASKS))]
    ada = [b for b in bagian if b is not None]
    if not ada:
        raise SystemExit(
            "BERHENTI: s3_cv.pkl maupun s3_ep*.pkl tidak ditemukan di "
            f"{CKPT}. Pastikan Drive sudah ter-mount dan BASE benar.")
    if len(ada) != len(TOX21_TASKS):
        print(f"PERINGATAN: baru {len(ada)}/{len(TOX21_TASKS)} titik akhir.")
    oof = pd.concat([b["oof"] for b in ada], ignore_index=True)
    print(f"Sumber: {len(ada)} berkas s3_ep*.pkl")

ens = oof[oof.model == "Ensemble"].copy()
if ens.empty:
    raise SystemExit("BERHENTI: tidak ada baris model 'Ensemble'. Model yang "
                     f"tersedia: {sorted(oof.model.unique())}")
hadir = [e for e in TOX21_TASKS if e in set(ens.endpoint)]
print(f"Ensemble: {len(ens):,} baris, {len(hadir)} titik akhir")

ens.to_csv(FIG / "oof_ensemble.csv.gz", index=False, compression="gzip")
print("Disimpan:", FIG / "oof_ensemble.csv.gz")

# ------------------------------------------------------------------ gaya ----
plt.rcParams.update({"font.family": "serif", "font.size": 9, "axes.grid": True,
                     "grid.alpha": .25, "grid.linewidth": .5,
                     "axes.axisbelow": True, "savefig.dpi": 300,
                     "savefig.bbox": "tight"})
BIRU, MERAH, ABU = "#2c5f8a", "#b3402f", "#4a4a4a"
WARNA = plt.cm.viridis(np.linspace(0, .92, len(hadir)))


def ambil(e):
    d = ens[ens.endpoint == e]
    return d.y_true.values.astype(int), d.probability.values.astype(float)


auc = {e: roc_auc_score(*ambil(e)) for e in hadir}
urut = sorted(hadir, key=lambda e: -auc[e])

# =========================================== 1. kurva ROC per titik akhir ====
fig, ax = plt.subplots(figsize=(9.2, 4.6))
for e, c in zip(urut, WARNA):
    y, p = ambil(e)
    fpr, tpr, _ = roc_curve(y, p)
    ax.plot(fpr, tpr, lw=1.3, color=c, label=f"{e}  ({auc[e]:.3f})")
ax.plot([0, 1], [0, 1], ls="--", lw=.8, color=ABU)
ax.text(.54, .49, "chance", fontsize=7, color=ABU, rotation=38)
ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
ax.set_xlim(0, 1); ax.set_ylim(0, 1.003)
ax.legend(frameon=False, fontsize=7.6, loc="center left",
          bbox_to_anchor=(1.01, .5), title="Endpoint (ROC-AUC)",
          title_fontsize=8)
fig.savefig(FIG / "Endpoint Specific2.png"); plt.close(fig)
print("OK  Endpoint Specific2.png")

# ====================================== 2. kurva presisi-recall per titik ====
fig, axes = plt.subplots(3, 4, figsize=(10.2, 7.4), sharex=True, sharey=True)
for ax, e in zip(axes.ravel(), urut):
    y, p = ambil(e)
    pr, rc, _ = precision_recall_curve(y, p)
    base = y.mean()
    ax.plot(rc, pr, lw=1.4, color=BIRU)
    ax.axhline(base, ls="--", lw=.8, color=MERAH)
    from sklearn.metrics import average_precision_score
    ax.set_title(f"{e}\nAP {average_precision_score(y, p):.3f}  "
                 f"(baseline {base:.3f})", fontsize=7.8)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.02)
for ax in axes[-1]:
    ax.set_xlabel("Recall", fontsize=8.5)
for ax in axes[:, 0]:
    ax.set_ylabel("Precision", fontsize=8.5)
fig.tight_layout()
fig.savefig(FIG / "Endpoint Specific3.png"); plt.close(fig)
print("OK  Endpoint Specific3.png")

# ================================================ 3. kurva keterandalan ======
NBIN = 10
fig, axes = plt.subplots(3, 4, figsize=(10.2, 7.4))
for ax, e in zip(axes.ravel(), urut):
    y, p = ambil(e)
    brier = float(np.mean((p - y) ** 2))
    # bin lebar-sama, tetapi atas rentang probabilitas yang benar-benar
    # teramati; atas [0,1] penuh sepuluh bin akan kosong semua kecuali satu,
    # karena kelas aktifnya jarang dan probabilitasnya menumpuk di bawah.
    tepi = np.linspace(0, p.max(), NBIN + 1)
    idx = np.clip(np.digitize(p, tepi) - 1, 0, NBIN - 1)
    xs, ys = [], []
    for b in range(NBIN):
        m = idx == b
        if m.sum() >= 5:
            xs.append(p[m].mean()); ys.append(y[m].mean())
    hi = max([*xs, *ys, .05]) * 1.15
    ax.plot([0, hi], [0, hi], ls="--", lw=.8, color=ABU)
    ax.plot(xs, ys, "-o", lw=1.3, ms=3.4, color=BIRU)
    ax.axhline(y.mean(), ls=":", lw=.9, color=MERAH)
    ax.set_xlim(0, hi); ax.set_ylim(0, hi)
    ax.tick_params(labelsize=7)
    ax.set_title(f"{e}   Brier {brier:.3f}", fontsize=8)
    ax.set_xlabel("Mean predicted prob.", fontsize=7.5)
    ax.set_ylabel("Observed freq.", fontsize=7.5)
fig.tight_layout()
fig.savefig(FIG / "08_calibration_curves.png"); plt.close(fig)
print("OK  08_calibration_curves.png")

# ============================ 4. ROC-AUC + selang kepercayaan bootstrap ======
B, rng = 1000, np.random.RandomState(42)
lo, hi = {}, {}
for e in urut:
    y, p = ambil(e)
    ia, ii = np.where(y == 1)[0], np.where(y == 0)[0]
    nilai = []
    for _ in range(B):
        s = np.concatenate([rng.choice(ia, len(ia), True),
                            rng.choice(ii, len(ii), True)])
        nilai.append(roc_auc_score(y[s], p[s]))
    lo[e], hi[e] = np.percentile(nilai, [2.5, 97.5])

fig, ax = plt.subplots(figsize=(7.6, 4.6))
yy = np.arange(len(urut))[::-1]
for k, e in enumerate(urut):
    ax.plot([lo[e], hi[e]], [yy[k], yy[k]], lw=1.5, color=BIRU,
            solid_capstyle="butt")
    ax.plot([lo[e], lo[e]], [yy[k] - .17, yy[k] + .17], lw=1.1, color=BIRU)
    ax.plot([hi[e], hi[e]], [yy[k] - .17, yy[k] + .17], lw=1.1, color=BIRU)
    ax.plot(auc[e], yy[k], "o", ms=5, color=MERAH, zorder=3)
    ax.text(hi[e] + .006, yy[k], f"{auc[e]:.3f}", va="center", fontsize=7.4)
rata = np.mean([auc[e] for e in urut])
ax.axvline(rata, ls="--", lw=.9, color=ABU)
ax.text(rata, -.55, f"panel mean {rata:.3f} ", fontsize=7.4,
        color=ABU, ha="right", va="center")
ax.set_yticks(yy); ax.set_yticklabels(urut, fontsize=8.5)
ax.set_xlabel("Ensemble ROC-AUC (out-of-fold, 95% stratified bootstrap CI)")
ax.set_ylim(-.7, len(urut) - .1)
ax.grid(axis="y", visible=False)
fig.savefig(FIG / "10_ensemble_roc_auc_confidence_intervals.png"); plt.close(fig)
print("OK  10_ensemble_roc_auc_confidence_intervals.png")

print("\nSelesai. Berkas ada di:", FIG)
print("Rata-rata ROC-AUC panel: %.4f  (harus 0,7929)" % rata)
