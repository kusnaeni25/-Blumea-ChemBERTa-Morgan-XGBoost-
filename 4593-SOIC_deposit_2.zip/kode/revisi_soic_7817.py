#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
REVISI SOIC 4593 — PROGRAM LENGKAP
A Hybrid ChemBERTa-Morgan XGBoost Ensemble ... Blumea balsamifera
================================================================================

SATU program untuk seluruh poin reviewer yang bisa dijawab secara komputasional.
Berdiri sendiri: tidak bergantung pada state notebook lama. Jalankan di Colab
dengan runtime CPU (GPU hanya mempercepat TAHAP 2 dan opsional TAHAP 9).

--------------------------------------------------------------------------------
CARA PAKAI
--------------------------------------------------------------------------------
    1. Unggah "ini saja.xlsx" ke /content
    2. Atur STAGES di bawah (default: semua kecuali yang opsional)
    3. Jalankan. Tiap tahap menyimpan checkpoint, jadi aman diputus dan
       dilanjutkan: jalankan ulang, tahap yang sudah selesai akan dilewati.

PERKIRAAN WAKTU di Colab CPU (2 vCPU):
    Tahap 1-2 (data + fitur)            : 20-30 menit
    Tahap 3 (CV utama)                  : 2-4 jam
    Tahap 3B (garis dasar protokol utama): 0,7 jam tanpa bagging pohon;
                                           ~4 jam dengan bagging pohon.
                                           Kalau baseline_utama_oof.csv.gz ada
                                           di folder keluaran, regresi logistik,
                                           SVM, dan random forest dipakai ulang
                                           dan tidak dihitung lagi.
    Tahap 4 (ablasi + imbalance)        : 2-3 jam; tujuh varian dipakai ulang
                                           dari s4_ablasi_7817.pkl bila ada,
                                           sehingga tinggal SMOTE-ENN
    Tahap 5 (model final + stabilitas)  : 40-60 menit
    Tahap 6 (uji kebocoran)             : 1,5-2,5 jam
    Tahap 7 (holdout kimia terjauh)     : 40-60 menit
    Tahap 8 (analisis post-hoc)         : 20-30 menit
    Tahap 9 (fine-tune ChemBERTa)       : 2-4 jam di GPU untuk 12 titik akhir;
                                           otomatis dilewati tanpa GPU, dan
                                           tidak menyimpan checkpoint kosong
                                           sehingga bisa diisi nanti

Set RUN_QUICK_TEST = True untuk uji jalan cepat pada 3 endpoint dan 1 repeat.

--------------------------------------------------------------------------------
PETA POIN REVIEWER
--------------------------------------------------------------------------------
Dijawab program ini:
    A1  uji signifikansi .................... Tahap 8.1 (DeLong + bootstrap
                                              berpasangan, Holm, penggabungan
                                              Stouffer dengan uji sensitivitas
                                              korelasi antar titik akhir)
    A2  ChemBERTa beku vs fine-tune ......... Tahap 9 (opsional, perlu GPU)
    A3  strategi ensemble alternatif ........ Tahap 3
    A4  penanganan class imbalance .......... Tahap 4 (scale_pos_weight, tanpa
                                              pembobotan, focal loss, SMOTE-ENN)
    A5  dampak eksklusi ..................... Tahap 1
    A6  arti dan CI skor prioritas .......... Tahap 5
    A7  karakteristik endpoint vs performa .. Tahap 8
    A12 baseline sederhana .................. Tahap 3B (regresi logistik, SVM
                                              linear, bagging pohon keputusan,
                                              MLP) - semuanya di protokol utama,
                                              sehingga langsung sebanding
                                              dengan ensemble
    A13 validasi eksternal (proksi) ......... Tahap 7
    A14 metrik AD di luar Tanimoto .......... Tahap 8
    A15 sensitivitas pembobotan ............. Tahap 8
    A-Q4 generalisasi out-of-distribution ... Tahap 7 dan 8
    B3  justifikasi bobot ensemble .......... Tahap 3
    B4  hyperparameter per endpoint ......... Tahap 4 (nested CV terbatas)
    B5  diagnostik kalibrasi ................ Tahap 8
    B6  sensitivitas threshold .............. Tahap 8
    B7  pola missingness .................... Tahap 8
    B8  cutoff AD dan stratifikasi .......... Tahap 8
    B9  kebocoran analog .................... Tahap 1 dan 6
    B13 pembobotan skor prioritas ........... Tahap 8
    B14 ablasi komponen ..................... Tahap 4
    B16 stabilitas ranking .................. Tahap 5
    B18 pemisahan sumber variabilitas ....... Tahap 8
    B19 analisis false negative ............. Tahap 8

TIDAK bisa dijawab program apa pun — ini pekerjaan menulis dan eksperimen:
    A8/A-Q7 interferensi asai flavonoid ..... Discussion, perlu kajian pustaka
    A9, A10, B20 positioning dan pustaka .... Introduction dan Discussion
    A11, B17 limitasi dan rekomendasi ....... Conclusion
    B1, B2 reframing dan klaim kebaruan ..... Abstract dan Introduction
    B10 ketersediaan kode ................... unggah ke GitHub/Zenodo
    B12 validasi eksperimental .............. laboratorium
    B15 multi-task learning ................. future work, dijawab argumen
    B21 Tox21 sebagai proksi toksisitas ..... Methods, argumen
================================================================================
"""

import os, json, pickle, warnings, time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")

# ==============================================================================
# KONFIGURASI
# ==============================================================================
# ------------------------------------------------------------------------------
# DATASET YANG SAHIH UNTUK NASKAH INI
# ------------------------------------------------------------------------------
# Seluruh angka naskah harus berasal dari himpunan 7.817 struktur, yaitu setelah
# pengeluaran 3 SMILES identik DAN 3 stereoisomer. Jalan lama (7.820) hanya
# membuang yang identik dan membiarkan stereoisomer bocor; checkpoint dari jalan
# itu TIDAK boleh dipakai ulang. Skrip ini memeriksanya sendiri dan menghapus
# checkpoint lanjutan yang tidak sesuai, satu kali, lalu menandainya.
N_STRUKTUR_SAHIH = 7817

STAGES = {
    1: True,   # data, kurasi, eksklusi stereo-aware
    2: True,   # fitur: Morgan, RDKit, ChemBERTa
    3: True,   # CV utama + strategi kombinasi
    "3B": True,  # garis dasar di protokol utama: logreg, SVM, RF, bagging pohon
    4: True,   # ablasi, imbalance (termasuk SMOTE-ENN, focal loss), nested CV
    5: True,   # model final, ranking, stabilitas antar-seed, CI
    6: True,   # uji kebocoran analog
    7: True,   # holdout kimia terjauh (proksi validasi eksternal)
    8: True,   # seluruh analisis post-hoc
    9: True,   # fine-tune ChemBERTa — otomatis dilewati bila tidak ada GPU
}

RUN_QUICK_TEST = False          # True = 3 endpoint, 1 repeat, bootstrap kecil

EXCEL_CANDIDATES = ["/content/ini saja.xlsx", "/content/ini saja(2).xlsx",
                    "/content/drive/MyDrive/ini saja.xlsx", "ini saja.xlsx"]
TOX21_URL = "https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/tox21.csv.gz"
CHEMBERTA_MODEL = "DeepChem/ChemBERTa-77M-MTR"

# PENTING: checkpoint disimpan di Google Drive, bukan di /content.
# /content terhapus setiap runtime Colab mati, sehingga seluruh tahap yang
# sudah selesai ikut hilang. Dengan Drive, program bisa dijalankan
# sepotong-sepotong lintas sesi: jalankan ulang dan ia lanjut dari tahap terakhir.
USE_DRIVE = True

if USE_DRIVE and Path("/content").exists():
    try:
        from google.colab import drive
        if not Path("/content/drive/MyDrive").exists():
            drive.mount("/content/drive")
        BASE = Path("/content/drive/MyDrive/revisi_soic")
        print("Checkpoint disimpan di Google Drive:", BASE)
    except Exception as _e:
        BASE = Path("/content/revisi_soic")
        print("Drive tidak tersedia, checkpoint lokal (HILANG bila runtime mati):", _e)
elif Path("/content").exists():
    BASE = Path("/content/revisi_soic")
else:
    BASE = Path("./revisi_soic")
CKPT, OUT, FIG = BASE / "checkpoints", BASE / "hasil", BASE / "hasil" / "figures"
for p in (CKPT, OUT, FIG):
    p.mkdir(parents=True, exist_ok=True)

TOX21_TASKS = ["NR-AR", "NR-AR-LBD", "NR-AhR", "NR-Aromatase", "NR-ER", "NR-ER-LBD",
               "NR-PPAR-gamma", "SR-ARE", "SR-ATAD5", "SR-HSE", "SR-MMP", "SR-p53"]
if RUN_QUICK_TEST:
    TOX21_TASKS = ["NR-AR", "SR-MMP", "NR-ER"]

SEED = 42
REPEAT_SEEDS = [42] if RUN_QUICK_TEST else [42, 73, 101]
N_SPLITS, INNER_SPLITS = 5, 5
N_BOOT = 200 if RUN_QUICK_TEST else 1000
CI = 0.95
FP_BITS, FP_RADIUS = 2048, 2
LEAKAGE_CUTOFFS = [0.9, 0.7]
AD_TANIMOTO_CUTOFF = 0.40

DESCRIPTOR_NAMES = ["MolWt", "MolLogP", "TPSA", "HBA", "HBD", "RotatableBonds",
                    "RingCount", "AromaticRings", "HeavyAtoms", "FractionCSP3", "QED",
                    "FormalCharge", "MolMR", "LabuteASA", "NumHeteroatoms",
                    "NumSaturatedRings"]


def save(name, obj):
    with open(CKPT / f"{name}.pkl", "wb") as f:
        pickle.dump(obj, f)


def load(name):
    p = CKPT / f"{name}.pkl"
    return pickle.load(open(p, "rb")) if p.exists() else None


def done(name):
    return (CKPT / f"{name}.pkl").exists()


def banner(txt):
    print("\n" + "=" * 78 + f"\n{txt}\n" + "=" * 78, flush=True)


T0 = time.time()


# ==============================================================================
# TAHAP 1 — DATA, KURASI, EKSKLUSI STEREO-AWARE                      [A5, B9]
# ==============================================================================
# PERBAIKAN PENTING terhadap pipeline lama. Eksklusi sebelumnya memakai
# canonical SMILES isomerik, sementara Morgan fingerprint dibuat tanpa
# useChirality. Akibatnya stereoisomer senyawa Blumea tetap tertinggal di
# data latih dengan fingerprint yang IDENTIK — kebocoran yang dilaporkan
# Reviewer B (poin 2.8). Di sini eksklusi dilakukan pada SMILES tanpa
# stereokimia, dan jumlah struktur tambahan yang terbuang dicatat.

if STAGES[1] and not done("s1_data"):
    banner("TAHAP 1 — data, kurasi, eksklusi stereo-aware")
    from rdkit import Chem, RDLogger
    from rdkit.Chem.Scaffolds import MurckoScaffold
    RDLogger.DisableLog("rdApp.*")

    def canon(s, iso=True):
        if pd.isna(s):
            return None
        m = Chem.MolFromSmiles(str(s).strip())
        return Chem.MolToSmiles(m, canonical=True, isomericSmiles=iso) if m else None

    def scaffold(s):
        m = Chem.MolFromSmiles(s)
        if m is None:
            return None
        sc = MurckoScaffold.MurckoScaffoldSmiles(mol=m, includeChirality=True)
        return sc if sc else f"ACYCLIC::{s}"

    def resolve(series):
        v = pd.to_numeric(series, errors="coerce").dropna().astype(int).unique()
        return float(v[0]) if len(v) == 1 else np.nan

    raw = pd.read_csv(TOX21_URL, compression="gzip")
    tox = raw[["smiles", *TOX21_TASKS]].copy()
    tox["canonical_smiles"] = [canon(x) for x in tox["smiles"]]
    n_invalid = int(tox["canonical_smiles"].isna().sum())
    tox = tox.dropna(subset=["canonical_smiles"])
    tox = tox.groupby("canonical_smiles", as_index=False).agg(
        {t: resolve for t in TOX21_TASKS})
    tox["flat_smiles"] = [canon(s, iso=False) for s in tox["canonical_smiles"]]
    tox["scaffold"] = tox["canonical_smiles"].map(scaffold)
    n_before = len(tox)

    xp = next((Path(p) for p in EXCEL_CANDIDATES if Path(p).exists()), None)
    if xp is None:
        raise FileNotFoundError("Letakkan 'ini saja.xlsx' di /content")
    braw = pd.read_excel(xp, sheet_name=0)
    braw["cs"] = braw["Canonical SMILES"].map(lambda s: canon(s))
    keep = [c for c in ["Skor Toksisitas", "computational toxicity priority"]
            if c in braw.columns]
    firstv = lambda s: s.dropna().iloc[0] if s.dropna().size else np.nan
    blumea = (braw.dropna(subset=["cs"]).groupby("cs", as_index=False)
              .agg({"Prediksi Senyawa": firstv, **{c: firstv for c in keep}})
              .rename(columns={"cs": "canonical_smiles",
                               "Prediksi Senyawa": "compound_name"}))
    blumea["flat_smiles"] = [canon(s, iso=False) for s in blumea["canonical_smiles"]]

    iso_set = set(blumea["canonical_smiles"])
    flat_set = set(blumea["flat_smiles"].dropna())

    mask_iso = tox["canonical_smiles"].isin(iso_set)
    mask_flat = tox["flat_smiles"].isin(flat_set)
    mask_stereo_only = mask_flat & ~mask_iso          # yang DULU lolos

    name_by_flat = {}
    for _, r in blumea.iterrows():
        if r["flat_smiles"]:
            name_by_flat.setdefault(r["flat_smiles"], r["compound_name"])

    audit_iso = tox[mask_iso].assign(
        blumea_compound=tox.loc[mask_iso, "flat_smiles"].map(name_by_flat),
        exclusion_reason="identical isomeric SMILES")
    audit_stereo = tox[mask_stereo_only].assign(
        blumea_compound=tox.loc[mask_stereo_only, "flat_smiles"].map(name_by_flat),
        exclusion_reason="stereoisomer / non-stereo duplicate (NEW)")
    overlap_audit = pd.concat([audit_iso, audit_stereo], ignore_index=True)

    tox = tox[~mask_flat].reset_index(drop=True)
    assert not set(tox["flat_smiles"]) & flat_set

    s1 = dict(tox=tox, blumea=blumea, overlap_audit=overlap_audit,
              n_invalid=n_invalid, n_before=n_before, n_after=len(tox),
              n_removed_iso=int(mask_iso.sum()),
              n_removed_stereo_only=int(mask_stereo_only.sum()))
    save("s1_data", s1)
    print(f"Tox21 valid unik           : {n_before}")
    print(f"Dibuang (SMILES identik)   : {s1['n_removed_iso']}")
    print(f"Dibuang (stereoisomer BARU): {s1['n_removed_stereo_only']}  <-- perbaikan")
    print(f"Tox21 dipakai              : {len(tox)}  "
          f"({100*(n_before-len(tox))/n_before:.3f}% dibuang)")
    print(f"Senyawa Blumea unik        : {len(blumea)}")
    overlap_audit.to_csv(OUT / "01_audit_eksklusi.csv", index=False)

s1 = load("s1_data")
tox, blumea = s1["tox"], s1["blumea"]

# ------------------------------------------------------------------ PREFLIGHT
banner("PREFLIGHT — memastikan dataset 7.817")
print(f"  struktur Tox21 dipakai : {len(tox)}")
print(f"  senyawa Blumea         : {len(blumea)}")
for k in ("n_before", "n_removed_iso", "n_removed_stereo_only", "n_after"):
    if k in s1:
        print(f"  {k:22s}: {s1[k]}")
if len(tox) != N_STRUKTUR_SAHIH:
    raise SystemExit(
        f"\nBERHENTI. Checkpoint s1_data memuat {len(tox)} struktur, "
        f"bukan {N_STRUKTUR_SAHIH}.\n"
        "Kemungkinan checkpoint berasal dari jalan lama tanpa eksklusi "
        "stereoisomer.\nHapus checkpoints/s1_data.pkl dan features.npz, "
        "lalu jalankan ulang dari Tahap 1.")
print("  OK — dataset sesuai.\n")

# ------------------------------------------------ PERIKSA CACHE FITUR
# features.npz menyimpan ti dan bi, yaitu pemetaan baris tox dan blumea ke
# daftar SMILES gabungan. Pemetaan itu dibuat dari tox YANG BERLAKU SAAT
# features.npz ditulis. Kalau berkas itu berasal dari jalan 7.820, panjang ti
# tidak sama dengan len(tox) dan program baru jatuh di tengah Tahap 3, setelah
# berjam-jam. Diperiksa di sini, sebelum apa pun dihitung.
#
# s2_features["n"] adalah jumlah SMILES unik gabungan tox + blumea. Nilai itu
# dapat dihitung ulang sekarang tanpa RDKit, jadi cocok sebagai sidik jari.
_n_harap = len(dict.fromkeys(tox["canonical_smiles"].tolist()
                             + blumea["canonical_smiles"].tolist()))
_s2 = load("s2_features")
_npz = CKPT / "features.npz"
_basi = []
if _s2 is not None and int(_s2.get("n", -1)) != _n_harap:
    _basi.append(f"s2_features n={_s2.get('n')} != {_n_harap} SMILES unik sekarang")
if _npz.exists():
    _z = np.load(_npz)
    if len(_z["ti"]) != len(tox):
        _basi.append(f"features.npz ti={len(_z['ti'])} != {len(tox)} baris tox")
    if len(_z["bi"]) != len(blumea):
        _basi.append(f"features.npz bi={len(_z['bi'])} != {len(blumea)} baris blumea")
    if len(_z["fp"]) != _n_harap:
        _basi.append(f"features.npz fp={len(_z['fp'])} != {_n_harap} SMILES unik")
    del _z
if _basi:
    print("  CACHE FITUR BASI:")
    for _b in _basi:
        print(f"    - {_b}")
    for _p in (_npz, CKPT / "s2_features.pkl"):
        if _p.exists():
            _p.unlink()
            print(f"    dihapus: {_p.name}")
    print("  Tahap 2 akan menghitung ulang fitur (20-30 menit, lebih cepat "
          "dengan GPU).\n")
elif _npz.exists():
    print("  OK — cache fitur sepadan dengan dataset "
          f"({_n_harap} SMILES unik).\n")
else:
    print(f"  Belum ada cache fitur; Tahap 2 akan menghitung {_n_harap} "
          "SMILES unik.\n")

# Hapus SEKALI checkpoint lanjutan yang mungkin berasal dari jalan 7.820.
#
# PENJAGA KEDUA, penting. Penanda bisa hilang karena berbagai sebab: folder
# disalin, Drive disinkronkan ulang, berkas .flag tidak ikut terbawa. Tanpa
# penjaga ini, hilangnya satu berkas kecil akan menghapus hasil belasan jam.
# Jadi sebelum menghapus apa pun, periksa dulu apakah s3_cv yang ada memang
# sudah konsisten dengan dataset sekarang. Kalau sudah, tulis penanda dan
# JANGAN hapus apa pun.
_tanda = CKPT / f"dataset_{N_STRUKTUR_SAHIH}.flag"
if not _tanda.exists():
    _s3_cek = load("s3_cv")
    try:
        _sudah_benar = (_s3_cek is not None and len(_s3_cek.get("oof", []))
                        and int(_s3_cek["oof"].tox21_row.max()) == len(tox) - 1)
    except Exception:
        _sudah_benar = False
    if _sudah_benar:
        _tanda.write_text(f"dataset {N_STRUKTUR_SAHIH} diverifikasi\n")
        print("  Penanda hilang, TETAPI s3_cv yang ada sudah konsisten dengan "
              f"{len(tox)} struktur.\n  Penanda ditulis ulang; tidak ada "
              "checkpoint yang dihapus.\n")
if not _tanda.exists():
    # s4_ablation pada arsip ini SUDAH memakai 7.817 struktur (lihat
    # Ringkasan_Eksklusi.csv: tox21_dipakai = 7817). Jadi jangan dibuang:
    # disalin ke s4_ablasi_7817.pkl agar Tahap 4 bisa memakainya ulang
    # varian demi varian, setelah tiap varian diperiksa sendiri.
    _p4 = CKPT / "s4_ablation.pkl"
    if _p4.exists():
        import shutil as _sh
        _sh.copyfile(_p4, CKPT / "s4_ablasi_7817.pkl")
        print("  s4_ablation disalin ke s4_ablasi_7817.pkl untuk dipakai ulang")
    for _nm in ("s3_cv", "s3b_baselines", "s4_ablation", "s5_ranking",
                "s6_leakage", "s7_holdout", "s8_posthoc", "s9_finetune"):
        _p = CKPT / f"{_nm}.pkl"
        if _p.exists():
            _p.unlink()
            print(f"  checkpoint lama dihapus: {_nm}.pkl")
    for _pola in ("s3_ep*.pkl", "s3b_ep*.pkl", "s4_ep*.pkl", "s9_ep*.pkl"):
        for _p in sorted(CKPT.glob(_pola)):
            _p.unlink()
            print(f"  checkpoint lama dihapus: {_p.name}")
    _tanda.write_text(f"dataset {N_STRUKTUR_SAHIH} diverifikasi\n")
    print("  Tahap 3 ke atas akan dihitung ulang dari awal.\n")
else:
    print("  Penanda dataset sudah ada; checkpoint lanjutan dipakai ulang.\n")


# ==============================================================================
# TAHAP 2 — FITUR
# ==============================================================================
if STAGES[2] and not done("s2_features"):
    banner("TAHAP 2 — fitur Morgan, RDKit, ChemBERTa")
    from rdkit import Chem, DataStructs
    from rdkit.Chem import AllChem, Descriptors, Crippen, Lipinski, rdMolDescriptors, QED

    all_smiles = list(dict.fromkeys(
        tox["canonical_smiles"].tolist() + blumea["canonical_smiles"].tolist()))
    gen = AllChem.GetMorganGenerator(radius=FP_RADIUS, fpSize=FP_BITS)
    fps, descs = [], []
    for i, smi in enumerate(all_smiles):
        if i % 2000 == 0:
            print(f"  fitur {i}/{len(all_smiles)}", flush=True)
        m = Chem.MolFromSmiles(smi)
        a = np.zeros((FP_BITS,), dtype=np.uint8)
        DataStructs.ConvertToNumpyArray(gen.GetFingerprint(m), a)
        fps.append(a)
        descs.append([Descriptors.MolWt(m), Crippen.MolLogP(m),
                      rdMolDescriptors.CalcTPSA(m), Lipinski.NumHAcceptors(m),
                      Lipinski.NumHDonors(m), Lipinski.NumRotatableBonds(m),
                      Lipinski.RingCount(m), Lipinski.NumAromaticRings(m),
                      Lipinski.HeavyAtomCount(m), rdMolDescriptors.CalcFractionCSP3(m),
                      QED.qed(m), Chem.GetFormalCharge(m), Crippen.MolMR(m),
                      rdMolDescriptors.CalcLabuteASA(m), Lipinski.NumHeteroatoms(m),
                      Lipinski.NumSaturatedRings(m)])
    fp_all = np.asarray(fps, dtype=np.float32)
    desc_all = np.asarray(descs, dtype=np.float32)

    import torch
    from transformers import AutoTokenizer, AutoModel
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("  ChemBERTa di", dev, flush=True)
    tok = AutoTokenizer.from_pretrained(CHEMBERTA_MODEL)
    enc = AutoModel.from_pretrained(CHEMBERTA_MODEL).to(dev).eval()
    embs = []
    for i in range(0, len(all_smiles), 64):
        if i % 1280 == 0:
            print(f"  embedding {i}/{len(all_smiles)}", flush=True)
        t = tok(all_smiles[i:i + 64], padding=True, truncation=True,
                max_length=256, return_tensors="pt")
        t = {k: v.to(dev) for k, v in t.items()}
        with torch.inference_mode():
            h = enc(**t).last_hidden_state
            m = t["attention_mask"].unsqueeze(-1).expand(h.size()).float()
            embs.append(((h * m).sum(1) / m.sum(1).clamp(min=1e-9)).cpu().numpy())
    chemberta_all = np.vstack(embs).astype(np.float32)
    del enc

    idx = {s: i for i, s in enumerate(all_smiles)}
    ti = np.array([idx[s] for s in tox["canonical_smiles"]])
    bi = np.array([idx[s] for s in blumea["canonical_smiles"]])
    np.savez_compressed(CKPT / "features.npz", fp=fp_all, desc=desc_all,
                        emb=chemberta_all, ti=ti, bi=bi)
    save("s2_features", {"n": len(all_smiles)})
    print("  Morgan", fp_all.shape, "| RDKit", desc_all.shape,
          "| ChemBERTa", chemberta_all.shape)

_f = np.load(CKPT / "features.npz")
fp_all, desc_all, emb_all = _f["fp"], _f["desc"], _f["emb"]
ti, bi = _f["ti"], _f["bi"]

# fp_all/desc_all/emb_all diindeks pada DAFTAR SMILES GABUNGAN, bukan pada
# baris Tox21. Jangan pernah memakainya langsung dengan mask sepanjang len(tox).
# Selalu pakai matriks ber-sufiks _t (Tox21) atau _b (Blumea) di bawah ini.
fp_t, desc_t, emb_t = fp_all[ti], desc_all[ti], emb_all[ti]
fp_b, desc_b, emb_b = fp_all[bi], desc_all[bi], emb_all[bi]

X_tox_m = np.hstack([fp_t, desc_t])
X_tox_c = np.hstack([emb_t, desc_t])
X_blu_m = np.hstack([fp_b, desc_b])
X_blu_c = np.hstack([emb_b, desc_b])

assert len(X_tox_m) == len(tox), (len(X_tox_m), len(tox))
assert len(X_blu_m) == len(blumea), (len(X_blu_m), len(blumea))


# ==============================================================================
# FUNGSI BERSAMA
# ==============================================================================
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (roc_auc_score, average_precision_score,
                             balanced_accuracy_score, matthews_corrcoef,
                             confusion_matrix, roc_curve, brier_score_loss,
                             accuracy_score, f1_score, precision_score, recall_score)
from xgboost import XGBClassifier

XGB_DEV = "cpu"
try:
    import torch as _t
    if _t.cuda.is_available():
        XGB_DEV = "cuda"
except Exception:
    pass


def make_xgb(seed=SEED, **kw):
    p = dict(n_estimators=350, max_depth=4, learning_rate=0.04, min_child_weight=2,
             subsample=0.80, colsample_bytree=0.70, reg_alpha=0.10, reg_lambda=2.0,
             objective="binary:logistic", eval_metric="logloss", tree_method="hist",
             device=XGB_DEV, random_state=seed, n_jobs=-1)
    p.update(kw)
    return XGBClassifier(**p)


def bal_w(y):
    y = np.asarray(y).astype(int)
    c = np.bincount(y, minlength=2)
    return np.array([len(y) / (2 * max(c[v], 1)) for v in y], dtype=float)


def logit(p):
    p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p)).reshape(-1, 1)


def platt(raw, y):
    m = LogisticRegression(C=1.0, solver="lbfgs", max_iter=2000)
    m.fit(logit(raw), np.asarray(y).astype(int))
    return m


def apply_cal(c, raw):
    return c.predict_proba(logit(raw))[:, 1]


def youden(y, p):
    y = np.asarray(y).astype(int)
    fpr, tpr, th = roc_curve(y, p)
    ok = np.isfinite(th)
    fpr, tpr, th = fpr[ok], tpr[ok], th[ok]
    j = tpr + (1 - fpr) - 1
    cand = np.where(np.isclose(j, j.max()))[0]
    b = cand[np.argmin(th[cand])]
    return float(th[b])


def splits(y, g, n, seed):
    y = np.asarray(y).astype(int); g = np.asarray(g)
    k = min(n, int(np.bincount(y).min()), len(np.unique(g)))
    if k < 3:
        raise ValueError("data tidak cukup")
    for off in range(50000):
        cv = StratifiedGroupKFold(n_splits=k, shuffle=True, random_state=int(seed + off))
        sp = list(cv.split(np.zeros(len(y)), y, g))
        if all(len(np.unique(y[a])) == 2 and len(np.unique(y[b])) == 2 for a, b in sp):
            return sp
    raise RuntimeError("split gagal")


def fit_fold(Xtr, ytr, Xte, bi_, ci_, seed, est="xgb", **kw):
    """Latih di base-training, kalibrasi Platt di calibration subset."""
    imp = SimpleImputer(strategy="median")
    Xb, Xc, Xt = imp.fit_transform(Xtr[bi_]), imp.transform(Xtr[ci_]), imp.transform(Xte)
    yb = ytr[bi_]
    if est == "xgb":
        m = make_xgb(seed, **kw)
        m.fit(Xb, yb, sample_weight=None if kw.get("scale_pos_weight") else bal_w(yb),
              verbose=False)
        rc, rt = m.predict_proba(Xc)[:, 1], m.predict_proba(Xt)[:, 1]
    else:
        sc = StandardScaler(with_mean=False)
        Xb2, Xc2, Xt2 = sc.fit_transform(Xb), sc.transform(Xc), sc.transform(Xt)
        if est == "logreg":
            m = LogisticRegression(C=1.0, max_iter=3000, solver="liblinear",
                                   class_weight="balanced", random_state=seed)
        else:
            m = CalibratedClassifierCV(
                LinearSVC(C=0.1, class_weight="balanced", max_iter=5000,
                          dual="auto", random_state=seed), method="sigmoid", cv=3)
        m.fit(Xb2, yb)
        rc, rt = m.predict_proba(Xc2)[:, 1], m.predict_proba(Xt2)[:, 1]
    cal = platt(rc, ytr[ci_])
    return apply_cal(cal, rt), apply_cal(cal, rc), rt


def metrics(y, p, pred):
    y = np.asarray(y).astype(int); pred = np.asarray(pred).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return dict(accuracy=accuracy_score(y, pred),
                balanced_accuracy=balanced_accuracy_score(y, pred),
                precision=precision_score(y, pred, zero_division=0),
                sensitivity=recall_score(y, pred, zero_division=0),
                specificity=tn / (tn + fp) if (tn + fp) else np.nan,
                f1=f1_score(y, pred, zero_division=0),
                mcc=matthews_corrcoef(y, pred), roc_auc=roc_auc_score(y, p),
                average_precision=average_precision_score(y, p),
                brier=brier_score_loss(y, p), tn=tn, fp=fp, fn=fn, tp=tp)


def endpoint_data(task):
    m = tox[task].notna().to_numpy()
    return (m, tox.loc[m, task].astype(int).to_numpy(),
            tox.loc[m, "scaffold"].astype(str).to_numpy())


BRANCHES = [("Morgan–XGBoost", X_tox_m, X_blu_m), ("ChemBERTa–XGBoost", X_tox_c, X_blu_c)]


# ==============================================================================
# TAHAP 3 — CV UTAMA + STRATEGI KOMBINASI                       [A3, B3, A1]
# ==============================================================================
# Bobot ensemble dan meta-learner stacking HANYA dilatih pada inner calibration
# subset. Ini menjawab "equal weight diasumsikan, bukan dioptimasi" tanpa
# menciptakan kebocoran baru ke outer test.

if STAGES[3] and not done("s3_cv"):
    banner("TAHAP 3 — cross-validation utama + strategi kombinasi")
    # Maximum dan Minimum probability ADA di tabel strategi kombinasi naskah
    # tetapi tidak pernah dihitung pipeline ini, sehingga setelah run ulang
    # kedua barisnya akan jadi angka tanpa sumber. Keduanya murni operasi atas
    # probabilitas yang sudah tersimpan, tanpa pemasangan model baru, jadi
    # biayanya nol.
    COMBOS = ["Equal-weight soft voting", "Performance-weighted voting",
              "Logistic stacking", "Rank averaging",
              "Maximum probability", "Minimum probability"]
    MODELS = [b[0] for b in BRANCHES] + ["Ensemble"] + COMBOS
    # Checkpoint disimpan PER TITIK AKHIR. Tahap ini 2-4 jam di data penuh;
    # kalau runtime Colab mati di tengah, hanya titik akhir yang sedang jalan
    # yang hilang, bukan seluruh tahap.
    for t_i, task in enumerate(TOX21_TASKS):
        if done(f"s3_ep{t_i:02d}"):
            print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task} — sudah ada, dilewati",
                  flush=True)
            continue
        t_ep = time.time()
        print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task}  "
              f"({(time.time()-T0)/60:.0f} mnt)", flush=True)
        oof_rows, met_rows, thr_rows = [], [], []
        mask, y, g = endpoint_data(task)
        rows_idx = np.where(mask)[0]
        acc = {m: [] for m in MODELS}
        accthr = {m: [] for m in MODELS}

        for r_i, rs in enumerate(REPEAT_SEEDS, 1):
            P = {m: np.full(len(y), np.nan) for m in MODELS}
            T = {m: np.full(len(y), np.nan) for m in MODELS}
            for fold, (tr, te) in enumerate(splits(y, g, N_SPLITS, rs), 1):
                isp = splits(y[tr], g[tr], INNER_SPLITS, rs + fold + 10000 * t_i)
                b_, c_ = isp[0]
                ycal = y[tr][c_]
                cal_p, test_p = {}, {}
                for m_i, (name, Xf, _) in enumerate(BRANCHES):
                    X = Xf[mask]
                    pt, pc, _ = fit_fold(X[tr], y[tr], X[te], b_, c_,
                                         rs + fold + 100 * m_i + 10000 * t_i)
                    P[name][te] = pt
                    T[name][te] = youden(ycal, pc)
                    cal_p[name], test_p[name] = pc, pt

                a, bn = BRANCHES[0][0], BRANCHES[1][0]
                ca, cb, ta, tb = cal_p[a], cal_p[bn], test_p[a], test_p[bn]

                eq_c, eq_t = (ca + cb) / 2, (ta + tb) / 2
                P["Ensemble"][te] = P["Equal-weight soft voting"][te] = eq_t
                th = youden(ycal, eq_c)
                T["Ensemble"][te] = T["Equal-weight soft voting"][te] = th

                try:
                    ea = max(roc_auc_score(ycal, ca) - .5, 1e-6)
                    eb = max(roc_auc_score(ycal, cb) - .5, 1e-6)
                except ValueError:
                    ea = eb = .5
                w = ea / (ea + eb)
                P["Performance-weighted voting"][te] = w * ta + (1 - w) * tb
                T["Performance-weighted voting"][te] = youden(ycal, w * ca + (1 - w) * cb)

                meta = LogisticRegression(C=1.0, max_iter=2000, class_weight="balanced")
                meta.fit(np.column_stack([ca, cb]), ycal)
                P["Logistic stacking"][te] = meta.predict_proba(
                    np.column_stack([ta, tb]))[:, 1]
                T["Logistic stacking"][te] = youden(
                    ycal, meta.predict_proba(np.column_stack([ca, cb]))[:, 1])

                rk = lambda v: stats.rankdata(v) / len(v)
                P["Rank averaging"][te] = (rk(ta) + rk(tb)) / 2
                T["Rank averaging"][te] = youden(ycal, (rk(ca) + rk(cb)) / 2)

                P["Maximum probability"][te] = np.maximum(ta, tb)
                T["Maximum probability"][te] = youden(ycal, np.maximum(ca, cb))
                P["Minimum probability"][te] = np.minimum(ta, tb)
                T["Minimum probability"][te] = youden(ycal, np.minimum(ca, cb))

            for m in MODELS:
                if np.isnan(P[m]).any():
                    continue
                acc[m].append(P[m]); accthr[m].append(T[m])
                pred = (P[m] >= T[m]).astype(int)
                met_rows.append(dict(endpoint=task, model=m, repeat=r_i,
                                     **metrics(y, P[m], pred)))
                thr_rows.append(dict(endpoint=task, model=m, repeat=r_i,
                                     median_threshold=float(np.median(T[m])),
                                     sd_threshold=float(np.std(T[m])),
                                     min_threshold=float(T[m].min()),
                                     max_threshold=float(T[m].max())))

        for m in MODELS:
            if not acc[m]:
                continue
            p = np.mean(np.vstack(acc[m]), 0)
            th = np.median(np.vstack(accthr[m]), 0)
            pred = (p >= th).astype(int)
            for li, oi in enumerate(rows_idx):
                oof_rows.append(dict(endpoint=task, model=m, tox21_row=int(oi),
                                     scaffold=g[li], y_true=int(y[li]),
                                     probability=float(p[li]),
                                     applied_threshold=float(th[li]),
                                     prediction=int(pred[li])))

        save(f"s3_ep{t_i:02d}", dict(oof=pd.DataFrame(oof_rows),
                                     metrics_repeat=pd.DataFrame(met_rows),
                                     thresholds=pd.DataFrame(thr_rows),
                                     n_struktur=len(tox)))
        print(f"      disimpan, {(time.time()-t_ep)/60:.1f} mnt", flush=True)

    bagian3 = [load(f"s3_ep{i:02d}") for i in range(len(TOX21_TASKS))]
    bagian3 = [b for b in bagian3 if b is not None]
    if len(bagian3) != len(TOX21_TASKS):
        raise SystemExit(
            f"\nBERHENTI. Baru {len(bagian3)}/{len(TOX21_TASKS)} titik akhir "
            "selesai di Tahap 3.\nJalankan ulang sel ini; yang sudah ada "
            "dilewati dan sisanya dilanjutkan.")
    if any(b["n_struktur"] != len(tox) for b in bagian3):
        raise SystemExit("BERHENTI: ada checkpoint s3_ep* dari dataset berbeda. "
                         "Hapus checkpoints/s3_ep*.pkl lalu jalankan ulang.")
    save("s3_cv", dict(
        oof=pd.concat([b["oof"] for b in bagian3], ignore_index=True),
        metrics_repeat=pd.concat([b["metrics_repeat"] for b in bagian3],
                                 ignore_index=True),
        thresholds=pd.concat([b["thresholds"] for b in bagian3],
                             ignore_index=True)))
    print("  Tahap 3 selesai dan digabung.")

s3 = load("s3_cv")


# ==============================================================================
# TAHAP 3B — GARIS DASAR DI PROTOKOL UTAMA                    [A12, A4-bagging]
#
#  Regresi logistik, SVM linear, random forest, dan bagging pohon keputusan,
#  dijalankan di bawah protokol yang IDENTIK dengan Tahap 3 sehingga angkanya
#  dapat dibandingkan langsung dengan ensemble, tanpa peringatan beda protokol.
#
#  Menjawab Reviewer A 6.1(a) regresi logistik, 6.1(b) SVM, dan 4.1 bagging.
# ==============================================================================
from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier

N_POHON_BAG = 150         # bagging pohon: seluruh fitur per pemecahan, jauh lebih berat
KEDALAMAN_BAG = 20

# SMOTE-ENN itu MAHAL: ENN melakukan pencarian tetangga terdekat pada ruang
# 2064 dimensi atas himpunan yang sudah diperbesar. Karena itu varian ini
# diberi saklar sendiri; matikan bila waktu mendesak, varian lain tidak
# terpengaruh. Penanganan ketidakseimbangan tetap terjawab oleh
# scale_pos_weight, tanpa pembobotan, pembobotan seimbang, dan focal loss.
IKUT_SMOTEENN = True

def buat(kelas, **kw):
    """Bangun objek sambil membuang argumen yang tidak dikenal versi terpasang.

    Perlu karena imbalanced-learn menghapus n_jobs dari SMOTE dan beberapa
    penyampel lain di versi 0.12 ke atas. Tanpa ini, satu TypeError akan
    menjatuhkan seluruh varian SMOTE-ENN di tengah Tahap 4.
    """
    sisa = dict(kw)
    for _ in range(len(kw) + 1):
        try:
            return kelas(**sisa)
        except TypeError as e:
            buruk = [k for k in sisa if f"'{k}'" in str(e)]
            if not buruk:
                raise
            for k in buruk:
                sisa.pop(k)
            print(f"      {kelas.__name__}: argumen {buruk} tidak dikenal, dibuang")
    return kelas()


try:
    from imblearn.combine import SMOTEENN
    from imblearn.over_sampling import SMOTE
    from imblearn.under_sampling import EditedNearestNeighbours
    ADA_IMBLEARN = IKUT_SMOTEENN
    if not IKUT_SMOTEENN:
        print("  catatan: SMOTE-ENN dimatikan lewat IKUT_SMOTEENN.")
except Exception:
    ADA_IMBLEARN = False
    print("  catatan: imbalanced-learn tidak ada, varian SMOTE-ENN dilewati.")
    print("           pasang dengan: pip install -q imbalanced-learn")


# ------------------------------------------------------------------ focal loss
def focal_obj(gamma=2.0, alpha=0.75, eps=1e-6):
    """Binary focal loss sebagai objective kustom XGBoost.

        L(y=1) = -alpha     * (1-p)^gamma * log(p)
        L(y=0) = -(1-alpha) *    p^gamma  * log(1-p)

    gamma menekan bobot contoh yang sudah mudah; alpha menaikkan bobot kelas
    minoritas. Gradien analitik terhadap logit; Hessian lewat beda hingga
    terpusat atas gradien itu sendiri, sehingga konsisten dengan gradiennya
    dan selalu positif.
    """
    def _loss(y, z):
        p = np.clip(1.0 / (1.0 + np.exp(-z)), eps, 1 - eps)
        return np.where(y == 1,
                        -alpha * (1 - p) ** gamma * np.log(p),
                        -(1 - alpha) * p ** gamma * np.log(1 - p))

    def _grad(y, z):
        p = np.clip(1.0 / (1.0 + np.exp(-z)), eps, 1 - eps)
        g1 = alpha * (gamma * (1 - p) ** gamma * p * np.log(p)
                      - (1 - p) ** (gamma + 1))
        g0 = (1 - alpha) * (-gamma * p ** gamma * (1 - p) * np.log(1 - p)
                            + p ** (gamma + 1))
        return np.where(y == 1, g1, g0)

    def obj(y_true, y_pred):
        y = np.asarray(y_true, dtype=float)
        z = np.asarray(y_pred, dtype=float)
        d = 1e-4
        h = (_grad(y, z + d) - _grad(y, z - d)) / (2 * d)
        return _grad(y, z), np.maximum(h, 1e-6)

    obj.loss = _loss
    obj.grad = _grad
    return obj


def uji_focal(verbose=True):
    """Gradien focal loss harus cocok dengan turunan numerik loss-nya,
    Hessian harus positif, dan tanda gradien harus benar."""
    o = focal_obj(2.0, 0.75)
    z = np.linspace(-6, 6, 241)
    d = 1e-5
    ok = True
    for y in (0.0, 1.0):
        yy = np.full_like(z, y)
        num = (o.loss(yy, z + d) - o.loss(yy, z - d)) / (2 * d)
        ana = o.grad(yy, z)
        e = np.max(np.abs(num - ana))
        g, h = o(yy, z)
        tanda = (g <= 0).all() if y == 1 else (g >= 0).all()
        ok &= (e < 1e-4) and (h > 0).all() and tanda
        if verbose:
            print(f"    y={int(y)}  |grad-numerik| maks={e:.2e}  "
                  f"Hessian>0: {bool((h > 0).all())}  tanda benar: {bool(tanda)}")
    print("    uji focal loss:", "LULUS" if ok else "GAGAL")
    return ok


_fit_fold_dasar = fit_fold


def fit_fold(Xtr, ytr, Xte, bi_, ci_, seed, est="xgb", **kw):
    """Perluasan fit_fold: menambah 'bag', 'mlp', 'xgb_focal', 'smoteenn'.
    Estimator lain diteruskan ke versi asli, tanpa perubahan apa pun."""
    if est not in ("bag", "mlp", "xgb_focal", "smoteenn"):
        return _fit_fold_dasar(Xtr, ytr, Xte, bi_, ci_, seed, est=est, **kw)
    imp = SimpleImputer(strategy="median")
    Xb = imp.fit_transform(Xtr[bi_]); Xc = imp.transform(Xtr[ci_]); Xt = imp.transform(Xte)
    yb = ytr[bi_]

    if est == "mlp":
        # Perceptron berlapis sebagai garis dasar jaringan saraf tiruan.
        # MLPClassifier tidak punya class_weight, jadi ketidakseimbangan
        # ditangani di hilir, sama seperti model lain: kalibrasi Platt lalu
        # ambang Youden. ROC-AUC dan AP sendiri tidak bergantung ambang.
        sc = StandardScaler(with_mean=False)
        Xb2, Xc2, Xt2 = sc.fit_transform(Xb), sc.transform(Xc), sc.transform(Xt)
        m = MLPClassifier(hidden_layer_sizes=(256, 64), activation="relu",
                          alpha=1e-3, batch_size=128, learning_rate_init=1e-3,
                          max_iter=200, early_stopping=True, n_iter_no_change=10,
                          validation_fraction=0.1, random_state=int(seed))
        m.fit(Xb2, yb)
        rc, rt = m.predict_proba(Xc2)[:, 1], m.predict_proba(Xt2)[:, 1]
        cal = platt(rc, ytr[ci_])
        return apply_cal(cal, rt), apply_cal(cal, rc), rt

    if est == "xgb_focal":
        gamma = kw.pop("gamma", 2.0); alpha = kw.pop("alpha", 0.75)
        m = make_xgb(seed, objective=focal_obj(gamma, alpha), **kw)
        m.fit(Xb, yb, verbose=False)
        # objective kustom -> keluaran adalah margin, bukan probabilitas
        rc = 1.0 / (1.0 + np.exp(-m.predict(Xc, output_margin=True)))
        rt = 1.0 / (1.0 + np.exp(-m.predict(Xt, output_margin=True)))
        cal = platt(rc, ytr[ci_])
        return apply_cal(cal, rt), apply_cal(cal, rc), rt

    if est == "smoteenn":
        # Resampling HANYA pada base-training. Subset kalibrasi dan lipatan uji
        # tetap pada distribusi aslinya, sehingga Platt dan Youden dipelajari
        # pada prevalensi yang benar dan tidak ada sintetis yang bocor.
        n_min = int(min((yb == 0).sum(), (yb == 1).sum()))
        if n_min >= 6:
            _t = time.time()
            sm = SMOTEENN(random_state=int(seed),
                          smote=buat(SMOTE, k_neighbors=min(5, n_min - 1),
                                     random_state=int(seed), n_jobs=-1),
                          enn=buat(EditedNearestNeighbours, n_neighbors=3,
                                   n_jobs=-1))
            try:
                n0 = len(yb)
                Xb, yb = sm.fit_resample(Xb, yb)
                print(f"      SMOTE-ENN {n0} -> {len(yb)} baris, "
                      f"aktif {yb.mean():.3f}, {time.time()-_t:.0f} s", flush=True)
            except Exception as e:
                print(f"      SMOTE-ENN gagal ({e}); fold dipakai tanpa resampling")
        else:
            print(f"      kelas minoritas hanya {n_min}; fold tanpa resampling")
        m = make_xgb(seed)
        m.fit(Xb, yb, verbose=False)   # resampling menggantikan pembobotan kelas
        rc, rt = m.predict_proba(Xc)[:, 1], m.predict_proba(Xt)[:, 1]
        cal = platt(rc, ytr[ci_])
        return apply_cal(cal, rt), apply_cal(cal, rc), rt

    # bagging harfiah: seluruh fitur dipertimbangkan di setiap pemecahan
    m = BaggingClassifier(
        estimator=DecisionTreeClassifier(min_samples_leaf=5,
                                         max_depth=KEDALAMAN_BAG,
                                         class_weight="balanced",
                                         random_state=int(seed)),
        n_estimators=N_POHON_BAG, max_samples=1.0, bootstrap=True,
        n_jobs=-1, random_state=int(seed))
    m.fit(Xb, yb)
    rc, rt = m.predict_proba(Xc)[:, 1], m.predict_proba(Xt)[:, 1]
    cal = platt(rc, ytr[ci_])
    return apply_cal(cal, rt), apply_cal(cal, rc), rt


uji_focal()


# Bagging diwakili bagging pohon keputusan saja, yaitu bentuk bagging yang
# harfiah: seluruh fitur dipertimbangkan di setiap pemecahan. Random forest
# tidak dipakai; ia bagging DENGAN subsampling fitur, jadi menjawab permintaan
# yang sama dua kali.
GARIS_DASAR = [("Logistic regression", "logreg"),
               ("Linear SVM", "svm"),
               ("Multilayer perceptron", "mlp"),
               ("Bagged decision trees", "bag")]

# Benih TIDAK boleh bergantung pada posisi di dalam daftar, sebab menambah satu
# pembelajar akan menggeser benih semua pembelajar sesudahnya dan membatalkan
# hasil yang sudah ada. Nomor di bawah ini permanen. Tiga yang pertama sengaja
# sama dengan revisi_soic_BASELINE_UTAMA.py (jalan semalam), sehingga hasilnya
# dapat dipakai ulang persis, bukan dihitung lagi.
# "rf" = 2 TETAP dicadangkan meskipun random forest tidak lagi dipakai. Kalau
# nomor itu dilepas dan mlp turun ke 2, benih mlp dan bagging ikut bergeser dan
# hasil yang sudah ada jadi tidak dapat direproduksi.
ID_DASAR = {"logreg": 0, "svm": 1, "rf": 2, "mlp": 3, "bag": 4}

# ------------------------------------------- pakai ulang jalan semalam
# baseline_utama_oof.csv.gz dan baseline_utama_per_repeat.csv dihasilkan oleh
# revisi_soic_BASELINE_UTAMA.py dengan lipatan, subset kalibrasi, dan benih yang
# identik dengan blok di bawah. Kalau berkas itu ada DAN jumlah barisnya cocok
# dengan dataset ini, regresi logistik, SVM, dan random forest tidak dihitung
# ulang. Kalau tidak cocok, berkas itu diabaikan dan semuanya dihitung dari awal.
DASAR_SIAP, DASAR_IMPOR = set(), None
_f_oof = OUT / "baseline_utama_oof.csv.gz"
_f_rep = OUT / "baseline_utama_per_repeat.csv"
if _f_oof.exists() and _f_rep.exists():
    try:
        _o = pd.read_csv(_f_oof)
        _r = pd.read_csv(_f_rep)
        _n_label = {t: int(tox[t].notna().sum()) for t in TOX21_TASKS}
        # Disaring ke GARIS_DASAR yang berlaku. Tanpa ini, model yang sudah
        # sengaja dikeluarkan (random forest) akan masuk lagi lewat jalur
        # impor dan muncul di tabel naskah tanpa pernah diminta.
        _dipakai = {nm for nm, _ in GARIS_DASAR}
        _sah = []
        for _nm in [m for m in _o.model.unique() if m in _dipakai]:
            _b = _o[_o.model == _nm]
            # Set titik akhir harus SAMA PERSIS, bukan sekadar memuat. Ini juga
            # yang membuat RUN_QUICK_TEST (3 titik akhir) menolak berkas 12
            # titik akhir, sehingga uji cepat tidak pernah mencampur keduanya.
            _ok = (set(_b.endpoint) == set(TOX21_TASKS)
                   and int(_b.tox21_row.max()) <= len(tox) - 1
                   and all(_b[_b.endpoint == t].tox21_row.nunique() == _n_label[t]
                           for t in TOX21_TASKS))
            print(f"  jalan semalam [{_nm}]: {'cocok' if _ok else 'TIDAK cocok'}"
                  f" dengan {len(tox)} struktur")
            if _ok:
                _sah.append(_nm)
        if _sah:
            DASAR_SIAP = set(_sah)
            DASAR_IMPOR = dict(oof=_o[_o.model.isin(_sah)].copy(),
                               metrics_repeat=_r[_r.model.isin(_sah)].copy())
            print(f"  -> {len(_sah)} pembelajar dipakai ulang, tidak dihitung lagi.")
    except Exception as _e:
        print(f"  jalan semalam tidak terbaca ({_e}); semua dihitung dari awal.")
else:
    print("  jalan semalam tidak ditemukan di folder keluaran; "
          "semua garis dasar dihitung dari awal.")

DASAR_HITUNG = [(nm, est) for nm, est in GARIS_DASAR if nm not in DASAR_SIAP]

if STAGES["3B"] and not done("s3b_baselines") and not DASAR_HITUNG:
    banner("TAHAP 3B — seluruhnya dari jalan semalam")
    save("s3b_baselines", DASAR_IMPOR)
    print("  Tidak ada yang perlu dihitung.")

if STAGES["3B"] and not done("s3b_baselines"):
    banner("TAHAP 3B — garis dasar di protokol utama")
    print(f"  perlu dihitung: {', '.join(nm for nm, _ in DASAR_HITUNG)}")
    print(f"  {len(DASAR_HITUNG)} pembelajar, {len(REPEAT_SEEDS)} pengulangan, "
          f"{N_SPLITS} lipatan.", flush=True)
    print("  Bagging pohon jauh paling lama: seluruh 2064 fitur dipertimbangkan "
          "di setiap\n  pemecahan, sementara random forest hanya akar dari itu. "
          "Checkpoint disimpan\n  per titik akhir, jadi sesi yang terputus bisa "
          "dilanjutkan tanpa kehilangan apa pun.", flush=True)
    for t_i, task in enumerate(TOX21_TASKS):
        if done(f"s3b_ep{t_i:02d}"):
            print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task} — sudah ada, dilewati",
                  flush=True)
            continue
        t_ep = time.time()
        print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task}  "
              f"({(time.time()-T0)/60:.0f} mnt berjalan)", flush=True)
        mask, y, g = endpoint_data(task)
        rows_idx = np.where(mask)[0]
        X = X_tox_m[mask]
        acc = {nm: [] for nm, _ in DASAR_HITUNG}
        accthr = {nm: [] for nm, _ in DASAR_HITUNG}
        oof_rows, met_rows = [], []
        for r_i, rs in enumerate(REPEAT_SEEDS, 1):
            P = {nm: np.full(len(y), np.nan) for nm, _ in DASAR_HITUNG}
            T = {nm: np.full(len(y), np.nan) for nm, _ in DASAR_HITUNG}
            for fold, (tr, te) in enumerate(splits(y, g, N_SPLITS, rs), 1):
                isp = splits(y[tr], g[tr], INNER_SPLITS, rs + fold + 10000 * t_i)
                b_, c_ = isp[0]
                ycal = y[tr][c_]
                for nm, est in DASAR_HITUNG:
                    pt, pc, _ = fit_fold(
                        X[tr], y[tr], X[te], b_, c_,
                        rs + fold + 100 * ID_DASAR[est] + 10000 * t_i, est=est)
                    P[nm][te] = pt
                    T[nm][te] = youden(ycal, pc)
            for nm, _ in DASAR_HITUNG:
                if np.isnan(P[nm]).any():
                    continue
                acc[nm].append(P[nm]); accthr[nm].append(T[nm])
                pred = (P[nm] >= T[nm]).astype(int)
                met_rows.append(dict(endpoint=task, model=nm, repeat=r_i,
                                     **metrics(y, P[nm], pred)))
            print(f"      pengulangan {r_i}/{len(REPEAT_SEEDS)} selesai "
                  f"({(time.time()-t_ep)/60:.1f} mnt)", flush=True)
        for nm, _ in DASAR_HITUNG:
            if not acc[nm]:
                continue
            p = np.mean(np.vstack(acc[nm]), 0)
            th = np.median(np.vstack(accthr[nm]), 0)
            pred = (p >= th).astype(int)
            for li, oi in enumerate(rows_idx):
                oof_rows.append(dict(endpoint=task, model=nm, tox21_row=int(oi),
                                     scaffold=g[li], y_true=int(y[li]),
                                     probability=float(p[li]),
                                     applied_threshold=float(th[li]),
                                     prediction=int(pred[li])))
        save(f"s3b_ep{t_i:02d}", dict(oof=pd.DataFrame(oof_rows),
                                      metrics_repeat=pd.DataFrame(met_rows),
                                      n_struktur=len(tox)))
        print(f"      disimpan, {(time.time()-t_ep)/60:.1f} mnt", flush=True)

    bagian = [load(f"s3b_ep{i:02d}") for i in range(len(TOX21_TASKS))]
    bagian = [b for b in bagian if b is not None]
    if len(bagian) != len(TOX21_TASKS):
        print(f"  PERINGATAN: baru {len(bagian)}/{len(TOX21_TASKS)} titik akhir "
              "selesai; Tahap 3B belum digabung. Jalankan ulang untuk melanjutkan.")
    else:
        salah = [b["n_struktur"] for b in bagian if b["n_struktur"] != len(tox)]
        if salah:
            raise SystemExit("BERHENTI: ada checkpoint 3B dari dataset berbeda. "
                             "Hapus checkpoints/s3b_ep*.pkl dan jalankan ulang.")
        _oofs = [b["oof"] for b in bagian]
        _reps = [b["metrics_repeat"] for b in bagian]
        if DASAR_IMPOR is not None:
            _oofs.append(DASAR_IMPOR["oof"])
            _reps.append(DASAR_IMPOR["metrics_repeat"])
        save("s3b_baselines",
             dict(oof=pd.concat(_oofs, ignore_index=True),
                  metrics_repeat=pd.concat(_reps, ignore_index=True)))
        print("  Tahap 3B selesai dan digabung"
              + (" (termasuk jalan semalam)." if DASAR_IMPOR is not None else "."))

s3b = load("s3b_baselines")

# ==============================================================================
# TAHAP 4 — ABLASI REPRESENTASI DAN PENANGANAN IMBALANCE      [B14, A4, B4]
# ==============================================================================
if STAGES[4] and not done("s4_ablation"):
    banner("TAHAP 4 — ablasi, baseline, imbalance, nested CV")
    # WAJIB terindeks baris Tox21 — lihat catatan di dekat definisi fp_t.
    # Regresi logistik, SVM, random forest, dan bagging pindah ke Tahap 3B,
    # tempatnya dijalankan di protokol utama. Blok ini kini murni ablasi
    # representasi ditambah penanganan ketidakseimbangan.
    #
    # Angka keempat adalah NOMOR BENIH PERMANEN. Nilainya sengaja sama dengan
    # posisi varian itu di revisi_soic_BAGGING_FOCAL.py, yang sudah dijalankan
    # pada 7.817 struktur. Dengan begitu tujuh varian pertama dapat dipakai
    # ulang persis dan hanya SMOTE-ENN yang perlu dihitung. Nomor tidak boleh
    # diubah atau dipakai ulang untuk varian lain.
    VARIANTS = {
        "Morgan only (no RDKit)": (fp_t, "xgb", {}, 0),
        "ChemBERTa only (no RDKit)": (emb_t, "xgb", {}, 1),
        "Morgan + RDKit": (X_tox_m, "xgb", {}, 2),
        "ChemBERTa + RDKit": (X_tox_c, "xgb", {}, 3),
        "XGBoost, no class weighting": (X_tox_m, "xgb", {"scale_pos_weight": 1.0}, 6),
        "XGBoost, scale_pos_weight": (X_tox_m, "xgb", {"scale_pos_weight": "auto"}, 7),
        "XGBoost, focal loss": (X_tox_m, "xgb_focal", {}, 9),
    }
    if ADA_IMBLEARN:
        VARIANTS["SMOTE-ENN resampling"] = (X_tox_m, "smoteenn", {}, 10)

    # ------------------------------------ pakai ulang ablasi 7.817 yang ada
    # s4_ablasi_7817.pkl adalah salinan s4_ablation dari jalan yang sudah
    # memakai 7.817 struktur. Barisnya diperiksa dulu: n dari matriks konfusi
    # harus sama dengan jumlah label tiap titik akhir. Yang lolos tidak
    # dihitung ulang.
    VAR_SIAP, IMPOR4 = set(), None
    _lama = load("s4_ablasi_7817")
    if _lama is not None and len(_lama.get("ablation", [])):
        _ab = _lama["ablation"]
        _nl = {t: int(tox[t].notna().sum()) for t in TOX21_TASKS}
        for _v in _ab.variant.unique():
            if _v not in VARIANTS:
                continue
            _b = _ab[_ab.variant == _v]
            _ok = (set(_b.endpoint) == set(TOX21_TASKS) and all(
                int(_b[_b.endpoint == t][["tn", "fp", "fn", "tp"]].to_numpy().sum())
                == _nl[t] for t in TOX21_TASKS))
            print(f"  ablasi lama [{_v}]: {'cocok' if _ok else 'TIDAK cocok'}")
            if _ok:
                VAR_SIAP.add(_v)
        if VAR_SIAP:
            IMPOR4 = {k: v[v.variant.isin(VAR_SIAP)].copy()
                      for k, v in _lama.items()
                      if isinstance(v, pd.DataFrame) and "variant" in v.columns}
            print(f"  -> {len(VAR_SIAP)} varian dipakai ulang.")
    _hitung = [k for k in VARIANTS if k not in VAR_SIAP]
    print(f"  perlu dihitung: {', '.join(_hitung) if _hitung else '(tidak ada)'}",
          flush=True)
    for _n, (_X, _, _, _) in VARIANTS.items():
        assert len(_X) == len(tox), f"{_n}: {len(_X)} != {len(tox)}"
    assert len(set(v[3] for v in VARIANTS.values())) == len(VARIANTS), \
        "nomor benih varian bentrok"
    seed0 = REPEAT_SEEDS[0]
    # Checkpoint per titik akhir, alasan sama seperti Tahap 3.
    for t_i, task in enumerate(TOX21_TASKS):
        if done(f"s4_ep{t_i:02d}"):
            print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task} — sudah ada, dilewati",
                  flush=True)
            continue
        print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task}  "
              f"({(time.time()-T0)/60:.0f} mnt)", flush=True)
        rows, uncal_rows = [], []
        mask, y, g = endpoint_data(task)
        sp = splits(y, g, N_SPLITS, seed0)
        for name, (Xf, est, kw, v_id) in VARIANTS.items():
            if name in VAR_SIAP:        # sudah ada dari jalan 7.817 sebelumnya
                continue
            X = Xf[mask]
            p = np.full(len(y), np.nan); pu = np.full(len(y), np.nan)
            thr = np.full(len(y), np.nan)
            for fold, (tr, te) in enumerate(sp, 1):
                isp = splits(y[tr], g[tr], INNER_SPLITS, seed0 + fold + 10000 * t_i)
                b_, c_ = isp[0]
                k = dict(kw)
                if k.get("scale_pos_weight") == "auto":
                    yy = y[tr][b_]
                    k["scale_pos_weight"] = float((yy == 0).sum() / max((yy == 1).sum(), 1))
                pt, pc, rt = fit_fold(X[tr], y[tr], X[te], b_, c_,
                                      seed0 + fold + 100 * v_id + 10000 * t_i,
                                      est, **k)
                p[te], pu[te], thr[te] = pt, rt, youden(y[tr][c_], pc)
            pred = (p >= thr).astype(int)
            rows.append(dict(endpoint=task, variant=name, **metrics(y, p, pred)))
            uncal_rows.append(dict(endpoint=task, variant=name,
                                   brier_calibrated=brier_score_loss(y, p),
                                   brier_uncalibrated=brier_score_loss(y, pu),
                                   roc_auc_calibrated=roc_auc_score(y, p),
                                   roc_auc_uncalibrated=roc_auc_score(y, pu)))
        save(f"s4_ep{t_i:02d}", dict(ablation=pd.DataFrame(rows),
                                     calibration_effect=pd.DataFrame(uncal_rows),
                                     n_struktur=len(tox)))

    # Nested CV hyperparameter pada 2 endpoint terbesar  [B4]
    grid = [dict(max_depth=3, learning_rate=.06), dict(max_depth=4, learning_rate=.04),
            dict(max_depth=6, learning_rate=.03)]
    nested = []
    big = sorted(TOX21_TASKS, key=lambda t: -int(tox[t].sum() if tox[t].notna().any() else 0))[:2]
    for t_i, task in enumerate(big):
        mask, y, g = endpoint_data(task)
        X = X_tox_m[mask]
        for fold, (tr, te) in enumerate(splits(y, g, N_SPLITS, seed0), 1):
            isp = splits(y[tr], g[tr], INNER_SPLITS, seed0 + fold)
            b_, c_ = isp[0]
            best, best_auc = None, -1
            for gi, gp in enumerate(grid):
                _, pc, _ = fit_fold(X[tr], y[tr], X[te][:1], b_, c_, seed0 + gi, **gp)
                a = roc_auc_score(y[tr][c_], pc)
                if a > best_auc:
                    best, best_auc = gp, a
            pt, _, _ = fit_fold(X[tr], y[tr], X[te], b_, c_, seed0 + fold, **best)
            nested.append(dict(endpoint=task, fold=fold, chosen=json.dumps(best),
                               inner_auc=best_auc, outer_auc=roc_auc_score(y[te], pt)))

    bagian4 = [load(f"s4_ep{i:02d}") for i in range(len(TOX21_TASKS))]
    bagian4 = [b for b in bagian4 if b is not None]
    if _hitung and len(bagian4) != len(TOX21_TASKS):
        raise SystemExit(
            f"\nBERHENTI. Baru {len(bagian4)}/{len(TOX21_TASKS)} titik akhir "
            "selesai di Tahap 4.\nJalankan ulang sel ini untuk melanjutkan.")
    if any(b["n_struktur"] != len(tox) for b in bagian4):
        raise SystemExit("BERHENTI: ada checkpoint s4_ep* dari dataset berbeda. "
                         "Hapus checkpoints/s4_ep*.pkl lalu jalankan ulang.")
    _kosong = pd.DataFrame(columns=["endpoint", "variant"])
    _ab_baru = (pd.concat([b["ablation"] for b in bagian4], ignore_index=True)
                if bagian4 else _kosong)
    _ue_baru = (pd.concat([b["calibration_effect"] for b in bagian4],
                          ignore_index=True) if bagian4 else _kosong)
    if IMPOR4 is not None:
        if "ablation" in IMPOR4:
            _ab_baru = pd.concat([IMPOR4["ablation"], _ab_baru], ignore_index=True)
        if "calibration_effect" in IMPOR4:
            _ue_baru = pd.concat([IMPOR4["calibration_effect"], _ue_baru],
                                 ignore_index=True)
    # Urutkan sesuai VARIANTS supaya tabel naskah tidak berubah urutan
    _urut = {k: i for i, k in enumerate(VARIANTS)}
    _ab_baru = (_ab_baru.assign(_u=_ab_baru.variant.map(_urut))
                .sort_values(["_u", "endpoint"]).drop(columns="_u")
                .reset_index(drop=True))
    save("s4_ablation", dict(ablation=_ab_baru,
                             calibration_effect=_ue_baru,
                             nested_cv=pd.DataFrame(nested)))
    print(f"  selesai — {_ab_baru.variant.nunique()} varian "
          f"({len(VAR_SIAP)} dipakai ulang, {len(_hitung)} dihitung)")

s4 = load("s4_ablation")


# ==============================================================================
# TAHAP 5 — MODEL FINAL, RANKING, STABILITAS ANTAR-SEED       [B16, A6, B13]
# ==============================================================================
if STAGES[5] and not done("s5_ranking"):
    banner("TAHAP 5 — model final, ranking, stabilitas")

    def final_predict(X, y, g, Xext, seed):
        sp = splits(y, g, INNER_SPLITS, seed + 5000)
        b_, c_ = sp[0]
        imp = SimpleImputer(strategy="median")
        Xb, Xc, Xe = imp.fit_transform(X[b_]), imp.transform(X[c_]), imp.transform(Xext)
        m = make_xgb(seed)
        m.fit(Xb, y[b_], sample_weight=bal_w(y[b_]), verbose=False)
        cal = platt(m.predict_proba(Xc)[:, 1], y[c_])
        return apply_cal(cal, m.predict_proba(Xe)[:, 1])

    per_seed = {s: pd.DataFrame({"compound_name": blumea["compound_name"].to_numpy()})
                for s in REPEAT_SEEDS}
    for t_i, task in enumerate(TOX21_TASKS):
        print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task}", flush=True)
        mask, y, g = endpoint_data(task)
        for rs in REPEAT_SEEDS:
            br = [final_predict(Xf[mask], y, g, Xe, rs + 100 * i + 10000 * t_i)
                  for i, (_, Xf, Xe) in enumerate(BRANCHES)]
            per_seed[rs][task] = (br[0] + br[1]) / 2

    mean_p = np.mean([per_seed[s][TOX21_TASKS].to_numpy() for s in REPEAT_SEEDS], 0)
    ss = pd.DataFrame({"compound_name": blumea["compound_name"].to_numpy()})
    for s in REPEAT_SEEDS:
        ss[f"score_seed_{s}"] = 100 * per_seed[s][TOX21_TASKS].to_numpy().mean(1)
        ss[f"rank_seed_{s}"] = ss[f"score_seed_{s}"].rank(ascending=False,
                                                          method="min").astype(int)
    rc = [f"rank_seed_{s}" for s in REPEAT_SEEDS]
    sc = [f"score_seed_{s}" for s in REPEAT_SEEDS]
    ss["rank_min"], ss["rank_max"] = ss[rc].min(1), ss[rc].max(1)
    ss["rank_range"] = ss["rank_max"] - ss["rank_min"]
    ss["score_mean"], ss["score_sd"] = ss[sc].mean(1), ss[sc].std(1, ddof=1)

    rng = np.random.default_rng(SEED)
    bt = np.array([100 * mean_p[:, rng.choice(mean_p.shape[1], mean_p.shape[1], True)].mean(1)
                   for _ in range(2000)])
    ss["score_ci_low"] = np.quantile(bt, .025, axis=0)
    ss["score_ci_high"] = np.quantile(bt, .975, axis=0)
    ss = ss.sort_values("score_mean", ascending=False).reset_index(drop=True)

    ag = []
    for i, a in enumerate(REPEAT_SEEDS):
        for b in REPEAT_SEEDS[i + 1:]:
            ag.append(dict(seed_a=a, seed_b=b,
                           spearman=stats.spearmanr(ss[f"score_seed_{a}"],
                                                    ss[f"score_seed_{b}"])[0],
                           kendall=stats.kendalltau(ss[f"score_seed_{a}"],
                                                    ss[f"score_seed_{b}"])[0],
                           top5_overlap=len(set(ss.nlargest(5, f"score_seed_{a}").compound_name)
                                            & set(ss.nlargest(5, f"score_seed_{b}").compound_name))))

    bp = pd.DataFrame(mean_p, columns=TOX21_TASKS)
    bp.insert(0, "compound_name", blumea["compound_name"].to_numpy())
    save("s5_ranking", dict(stability=ss, agreement=pd.DataFrame(ag),
                            blumea_prob=bp, per_seed=per_seed))
    print(pd.DataFrame(ag).round(3).to_string(index=False))

s5 = load("s5_ranking")


# ==============================================================================
# TAHAP 6 — UJI KEBOCORAN ANALOG                            [B9, pertanyaan A4]
# ==============================================================================
if STAGES[6] and not done("s6_leakage"):
    banner("TAHAP 6 — uji kebocoran analog")
    fpb = (fp_all > 0).astype(np.float32)
    pc_tox, pc_blu = fpb[ti].sum(1), fpb[bi].sum(1)
    inter = fpb[ti] @ fpb[bi].T
    union = pc_tox[:, None] + pc_blu[None, :] - inter
    max_sim = np.max(inter / np.maximum(union, 1e-9), axis=1)
    print(f"  similaritas maks Tox21->Blumea: median {np.median(max_sim):.3f}, "
          f">0.7: {(max_sim>0.7).sum()}, >0.9: {(max_sim>0.9).sum()}")

    perf, ranks = [], {}
    seed0 = REPEAT_SEEDS[0]
    for cut in LEAKAGE_CUTOFFS:
        keep = max_sim < cut
        print(f"  cutoff {cut}: buang {int((~keep).sum())}, sisa {int(keep.sum())}",
              flush=True)
        toxf = tox[keep].reset_index(drop=True)
        Xm, Xc = X_tox_m[keep], X_tox_c[keep]
        scores = np.full((len(blumea), len(TOX21_TASKS)), np.nan)
        for t_i, task in enumerate(TOX21_TASKS):
            m = toxf[task].notna().to_numpy()
            y = toxf.loc[m, task].astype(int).to_numpy()
            g = toxf.loc[m, "scaffold"].astype(str).to_numpy()
            if len(np.unique(y)) < 2 or y.sum() < 10:
                continue
            p = np.full(len(y), np.nan)
            for fold, (tr, te) in enumerate(splits(y, g, N_SPLITS, seed0), 1):
                isp = splits(y[tr], g[tr], INNER_SPLITS, seed0 + fold + 10000 * t_i)
                b_, c_ = isp[0]
                pa, _, _ = fit_fold(Xm[m][tr], y[tr], Xm[m][te], b_, c_, seed0 + fold)
                pb, _, _ = fit_fold(Xc[m][tr], y[tr], Xc[m][te], b_, c_, 142 + fold)
                p[te] = (pa + pb) / 2
            perf.append(dict(cutoff=cut, endpoint=task, n_train=int(m.sum()),
                             roc_auc=roc_auc_score(y, p),
                             average_precision=average_precision_score(y, p)))

            def fin(X, Xe, sd):
                sp = splits(y, g, INNER_SPLITS, sd + 5000); b2, c2 = sp[0]
                imp = SimpleImputer(strategy="median")
                Xb, Xc2, Xe2 = imp.fit_transform(X[b2]), imp.transform(X[c2]), imp.transform(Xe)
                mm = make_xgb(sd); mm.fit(Xb, y[b2], sample_weight=bal_w(y[b2]), verbose=False)
                return apply_cal(platt(mm.predict_proba(Xc2)[:, 1], y[c2]),
                                 mm.predict_proba(Xe2)[:, 1])
            scores[:, t_i] = (fin(Xm[m], X_blu_m, seed0 + 10000 * t_i)
                              + fin(Xc[m], X_blu_c, 142 + 10000 * t_i)) / 2
        ranks[cut] = 100 * np.nanmean(scores, axis=1)

    cmp = pd.DataFrame({"compound_name": blumea["compound_name"].to_numpy(),
                        "score_original": s5["stability"].set_index("compound_name")
                        .reindex(blumea["compound_name"])["score_mean"].to_numpy()})
    agr = []
    for cut, v in ranks.items():
        cmp[f"score_cut_{cut}"] = v
        ok = cmp.dropna(subset=[f"score_cut_{cut}", "score_original"])
        agr.append(dict(cutoff=cut, n_removed=int((max_sim >= cut).sum()),
                        spearman=stats.spearmanr(ok["score_original"],
                                                 ok[f"score_cut_{cut}"])[0],
                        top5_overlap=len(set(cmp.nlargest(5, "score_original").compound_name)
                                         & set(ok.nlargest(5, f"score_cut_{cut}").compound_name)),
                        mean_roc_auc=pd.DataFrame(perf).query("cutoff==@cut")["roc_auc"].mean()))
    save("s6_leakage", dict(performance=pd.DataFrame(perf), comparison=cmp,
                            agreement=pd.DataFrame(agr), max_sim=max_sim))
    print(pd.DataFrame(agr).round(3).to_string(index=False))

s6 = load("s6_leakage")


# ==============================================================================
# TAHAP 7 — HOLDOUT KIMIA TERJAUH (PROKSI VALIDASI EKSTERNAL)  [A13, B11, A-Q4]
# ==============================================================================
# Bukan validasi eksternal sejati — tidak ada dataset independen. Yang diuji:
# 20% scaffold yang PALING JAUH dari sisa data dipakai sebagai test set,
# meniru situasi menerapkan model pada kelas senyawa yang belum pernah dilihat.
# Laporkan apa adanya sebagai batas atas kesulitan, bukan sebagai validasi eksternal.

if STAGES[7] and not done("s7_holdout"):
    banner("TAHAP 7 — holdout kimia terjauh")
    fpb = (fp_all > 0).astype(np.float32)
    rows = []
    for t_i, task in enumerate(TOX21_TASKS):
        print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task}", flush=True)
        mask, y, g = endpoint_data(task)
        F = fpb[ti][mask]
        pc = F.sum(1)
        # similaritas rata-rata tiap scaffold ke seluruh data
        uniq = pd.unique(g)
        cent = {}
        for s in uniq:
            idx = np.where(g == s)[0]
            cent[s] = idx[0]
        ci_ = np.array([cent[s] for s in uniq])
        I = F[ci_] @ F.T
        U = pc[ci_][:, None] + pc[None, :] - I
        mean_sim = (I / np.maximum(U, 1e-9)).mean(1)
        order = uniq[np.argsort(mean_sim)]           # paling jauh dulu
        te_sc, n_t = set(), 0
        for s in order:
            te_sc.add(s); n_t += (g == s).sum()
            if n_t >= .2 * len(y):
                break
        te = np.array([s in te_sc for s in g])
        tr = ~te
        if len(np.unique(y[te])) < 2 or len(np.unique(y[tr])) < 2:
            continue
        itr = np.where(tr)[0]
        isp = splits(y[itr], g[itr], INNER_SPLITS, SEED + t_i)
        b_, c_ = isp[0]
        ps = []
        for i, (_, Xf, _) in enumerate(BRANCHES):
            X = Xf[mask]
            pt, pc2, _ = fit_fold(X[itr], y[itr], X[te], b_, c_, SEED + 100 * i + t_i)
            ps.append((pt, pc2))
        p = (ps[0][0] + ps[1][0]) / 2
        th = youden(y[itr][c_], (ps[0][1] + ps[1][1]) / 2)
        rows.append(dict(endpoint=task, n_test=int(te.sum()),
                         n_test_active=int(y[te].sum()),
                         mean_scaffold_similarity=float(np.sort(mean_sim)[:len(te_sc)].mean()),
                         **metrics(y[te], p, (p >= th).astype(int))))
    save("s7_holdout", pd.DataFrame(rows))
    print(pd.DataFrame(rows)[["endpoint", "roc_auc", "average_precision", "mcc"]]
          .round(3).to_string(index=False))

s7 = load("s7_holdout")


# ==============================================================================
# TAHAP 8 — ANALISIS POST-HOC      [A1,A7,A14,A15,B5,B6,B7,B8,B13,B18,B19]
# ==============================================================================
# ---------------------------------------------------------------- DeLong
# Uji DeLong untuk dua ROC-AUC berkorelasi pada SUBJEK YANG SAMA, varian
# cepat Sun & Xu (2014). Dipakai karena Reviewer A dan B secara eksplisit
# menyebut DeLong dan bootstrap; keduanya dilaporkan berdampingan.
#
# BATASAN YANG HARUS DINYATAKAN DI NASKAH, jangan dihilangkan.
# DeLong dirancang untuk SATU himpunan prediksi per subjek. Di sini ia
# diterapkan pada probabilitas luar-lipatan yang sudah dirata-ratakan atas
# tiga pengulangan, sehingga memang satu nilai per senyawa. Konsekuensinya:
#   1. ragam DeLong hanya mencakup ragam pengambilan sampel senyawa, BUKAN
#      ragam antar-pengulangan. Jadi nilai p-nya cenderung anti-konservatif.
#   2. karena itu bootstrap berpasangan tetap dilaporkan di sebelahnya, dan
#      penggabungan Stouffer disertai uji sensitivitas korelasi antar titik
#      akhir. Kesimpulan hanya diambil bila ketiganya searah.
#   3. DeLong tidak berlaku untuk average precision. Untuk AP dipakai z
#      bertanda dari bootstrap, dan kolom z_sumber mencatat yang mana.
# Ini sekaligus menjawab keberatan yang dulu dipakai untuk MENOLAK DeLong;
# keberatan itu benar, dan di sini dijawab lewat pelaporan berdampingan,
# bukan dengan berpura-pura tidak ada.
def _midrank(x):
    x = np.asarray(x, float)
    o = np.argsort(x, kind="mergesort")
    xs = x[o]
    n = len(x)
    r = np.empty(n, float)
    i = 0
    while i < n:
        j = i
        while j < n - 1 and xs[j + 1] == xs[i]:
            j += 1
        r[i:j + 1] = 0.5 * (i + j) + 1
        i = j + 1
    out = np.empty(n, float)
    out[o] = r
    return out

def delong(y, p1, p2):
    """Kembalikan (auc1, auc2, z, p_dua_sisi). z>0 berarti p1 lebih baik."""
    y = np.asarray(y).astype(int)
    order = (-y).argsort(kind="mergesort")
    m = int(y.sum()); n = len(y) - m
    if m == 0 or n == 0:
        return np.nan, np.nan, np.nan, np.nan
    P = np.vstack((np.asarray(p1, float), np.asarray(p2, float)))[:, order]
    pos, neg = P[:, :m], P[:, m:]
    tx = np.empty((2, m)); ty = np.empty((2, n)); tz = np.empty((2, m + n))
    for r in range(2):
        tx[r] = _midrank(pos[r]); ty[r] = _midrank(neg[r]); tz[r] = _midrank(P[r])
    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1) / 2.0 / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    cov = np.cov(v01) / m + np.cov(v10) / n
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    if not np.isfinite(var) or var <= 0:
        return aucs[0], aucs[1], np.nan, np.nan
    z = (aucs[0] - aucs[1]) / np.sqrt(var)
    return aucs[0], aucs[1], z, float(2 * stats.norm.sf(abs(z)))

def stouffer(zs, r=0.0):
    """Gabungkan z antar titik akhir. r = korelasi ekuivalen yang
    diasumsikan antar titik akhir; r=0 berarti saling bebas.

    Mengembalikan (z, p_dua_sisi, p_satu_sisi, k). Yang DILAPORKAN di
    naskah adalah p dua sisi. Alasannya praktis: arah keunggulan ensemble
    tidak pernah dinyatakan sebagai hipotesis berarah di muka, dan
    melaporkan p satu sisi tanpa pra-registrasi arah adalah hal pertama
    yang akan ditanyakan penelaah statistik. p satu sisi tetap disimpan
    agar bisa dikutip bila memang diminta, dengan labelnya jelas.
    """
    z = np.asarray([v for v in zs if np.isfinite(v)], float)
    k = len(z)
    if k == 0:
        return np.nan, np.nan, np.nan, 0
    var = k + k * (k - 1) * r
    if var <= 0:
        return np.nan, np.nan, np.nan, k
    zc = z.sum() / np.sqrt(var)
    return (float(zc), float(2 * stats.norm.sf(abs(zc))),
            float(stats.norm.sf(zc)), k)


if STAGES[8] and not done("s8_posthoc"):
    banner("TAHAP 8 — analisis post-hoc")
    oof = s3["oof"]; R = {}

    def fauc(y, p):
        y = np.asarray(y); n1 = y.sum(); n0 = len(y) - n1
        if n1 == 0 or n0 == 0:
            return np.nan
        r = stats.rankdata(p)
        return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)

    def fap(y, p):
        y = np.asarray(y); o = np.argsort(-np.asarray(p, float)); ys = y[o]
        return float((np.cumsum(ys) / np.arange(1, len(ys) + 1) * ys).sum()
                     / max(ys.sum(), 1))

    def pboot(y, pa, pb, fn, n=N_BOOT, seed=SEED):
        y = np.asarray(y).astype(int)
        pos, neg = np.where(y == 1)[0], np.where(y == 0)[0]
        rng = np.random.default_rng(seed); obs = fn(y, pa) - fn(y, pb)
        d = np.empty(n)
        for b in range(n):
            i = np.concatenate([rng.choice(pos, len(pos), True),
                                rng.choice(neg, len(neg), True)])
            yb = y[i]
            d[b] = fn(yb, pa[i]) - fn(yb, pb[i]) if 0 < yb.sum() < len(yb) else np.nan
        d = d[np.isfinite(d)]; a = (1 - CI) / 2
        return obs, *np.quantile(d, [a, 1 - a]), min(
            2 * min((d <= 0).mean(), (d >= 0).mean()), 1.0)

    def holm(p):
        p = np.asarray(p, float); n = len(p); o = np.argsort(p)
        adj = np.empty(n); run = 0.
        for r, i in enumerate(o):
            run = max(run, (n - r) * p[i]); adj[i] = min(run, 1.)
        return adj

    # 8.1 signifikansi
    print("  8.1 signifikansi", flush=True)
    # Garis dasar Tahap 3B dijalankan di protokol yang identik, jadi boleh
    # digabung ke himpunan yang sama dan diuji dengan cara yang sama.
    oof_sig = oof
    if s3b is not None and len(s3b.get("oof", [])):
        oof_sig = pd.concat([oof, s3b["oof"]], ignore_index=True)
    DASAR = [nm for nm, _ in GARIS_DASAR]
    # Setiap strategi kombinasi diuji terhadap pemungutan suara berbobot sama,
    # karena itulah yang dilaporkan kolom p di tabel strategi kombinasi.
    _KOMBO = ["Performance-weighted voting", "Logistic stacking",
              "Rank averaging", "Maximum probability", "Minimum probability"]
    pairs = ([("Ensemble", "Morgan–XGBoost"), ("Ensemble", "ChemBERTa–XGBoost"),
              ("Morgan–XGBoost", "ChemBERTa–XGBoost")]
             + [(nm, "Equal-weight soft voting") for nm in _KOMBO]
             + [("Ensemble", nm) for nm in DASAR])
    rows = []
    for task in TOX21_TASKS:
        s_ = oof_sig[oof_sig.endpoint == task]
        pv = s_.pivot_table(index="tox21_row", columns="model",
                            values="probability", aggfunc="mean")
        y = (s_.drop_duplicates("tox21_row").set_index("tox21_row")
             .loc[pv.index, "y_true"].to_numpy())
        for a, b in pairs:
            if a not in pv or b not in pv:
                continue
            pa, pb = pv[a].to_numpy(), pv[b].to_numpy()
            ok = np.isfinite(pa) & np.isfinite(pb)
            if ok.sum() < 20 or len(np.unique(y[ok])) < 2:
                continue
            ya, pa, pb = y[ok], pa[ok], pb[ok]
            _, _, zd, pd_ = delong(ya, pa, pb)
            for mn, fn in [("roc_auc", fauc), ("average_precision", fap)]:
                o, lo, hi, p = pboot(ya, pa, pb, fn)
                # z bertanda dari p bootstrap dua sisi, untuk digabung Stouffer
                pp = min(max(p, 1e-12), 1 - 1e-12)
                zb = float(np.sign(o) * stats.norm.isf(pp / 2))
                rows.append(dict(endpoint=task, model_a=a, model_b=b, metric=mn,
                                 difference=o, ci_low=lo, ci_high=hi, p_raw=p,
                                 z_bootstrap=zb,
                                 value_a=fn(ya, pa), value_b=fn(ya, pb),
                                 n_evaluated=int(ok.sum()),
                                 delong_z=zd if mn == "roc_auc" else np.nan,
                                 delong_p=pd_ if mn == "roc_auc" else np.nan))
    sig = pd.DataFrame(rows); sig["p_holm"] = np.nan
    sig["delong_p_holm"] = np.nan
    for _, blk in sig.groupby(["model_a", "model_b", "metric"]):
        sig.loc[blk.index, "p_holm"] = holm(blk.p_raw.to_numpy())
        dp = blk.delong_p.to_numpy()
        if np.isfinite(dp).all():
            sig.loc[blk.index, "delong_p_holm"] = holm(dp)
    sig["significant"] = sig.p_holm < .05
    sig["delong_significant"] = sig.delong_p_holm < .05
    agg = []
    for (a, b, m), blk in sig.groupby(["model_a", "model_b", "metric"]):
        d = blk.difference.to_numpy(); rng = np.random.default_rng(SEED)
        bm = np.array([rng.choice(d, len(d), True).mean() for _ in range(5000)])
        al = (1 - CI) / 2
        baris = dict(model_a=a, model_b=b, metric=m, n_endpoints=len(d),
                     mean_difference=d.mean(),
                     ci_low=np.quantile(bm, al), ci_high=np.quantile(bm, 1 - al),
                     n_favoring_a=int((d > 0).sum()),
                     n_significant=int(blk.significant.sum()),
                     # DeLong hanya berlaku bagi ROC-AUC; untuk AP dikosongkan
                     # supaya tidak terbaca sebagai "nol yang signifikan".
                     n_delong_significant=(int(blk.delong_significant.sum())
                                           if m == "roc_auc" else np.nan))
        # Penggabungan Stouffer: DeLong untuk ROC-AUC, bootstrap untuk AP.
        zs = (blk.delong_z.to_numpy() if m == "roc_auc"
              else blk.z_bootstrap.to_numpy())
        baris["z_sumber"] = "DeLong" if m == "roc_auc" else "bootstrap"
        for r_ in (0.0, 0.1, 0.2, 0.3, 0.5):
            zc, p2, p1, k = stouffer(zs, r_)
            baris[f"stouffer_z_r{r_:g}"] = zc
            baris[f"stouffer_p2sisi_r{r_:g}"] = p2      # yang dilaporkan
            baris[f"stouffer_p1sisi_r{r_:g}"] = p1      # cadangan, berlabel
        agg.append(baris)
    R["significance"], R["significance_summary"] = sig, pd.DataFrame(agg)

    # Ringkasan kecil yang langsung bisa dikutip di naskah.
    _pokok = pd.DataFrame(agg)
    _pokok = _pokok[(_pokok.model_a == "Ensemble")]
    if len(_pokok):
        print(_pokok[["model_b", "metric", "mean_difference", "n_favoring_a",
                      "n_significant", "stouffer_p2sisi_r0.2"]]
              .round(4).to_string(index=False), flush=True)

    # 8.2 karakteristik endpoint + missingness
    print("  8.2 karakteristik endpoint", flush=True)
    ec = []
    for t in TOX21_TASKS:
        lab = tox[t].notna(); y = tox.loc[lab, t].astype(int); scf = tox.loc[lab, "scaffold"]
        ec.append(dict(endpoint=t, n_labeled=int(lab.sum()), n_missing=int((~lab).sum()),
                       missing_fraction=float((~lab).mean()), n_active=int(y.sum()),
                       active_prevalence=float(y.mean()),
                       n_unique_scaffolds=int(scf.nunique()),
                       scaffold_per_compound=float(scf.nunique() / lab.sum()),
                       n_active_scaffolds=int(scf[y == 1].nunique())))
    ec = pd.DataFrame(ec).merge(
        s3["oof"][s3["oof"].model == "Ensemble"].groupby("endpoint")
        .apply(lambda d: pd.Series(dict(roc_auc=roc_auc_score(d.y_true, d.probability),
                                        average_precision=average_precision_score(d.y_true, d.probability),
                                        mcc=matthews_corrcoef(d.y_true, d.prediction))),
               include_groups=False).reset_index(), on="endpoint")
    R["endpoint_characteristics"] = ec
    R["endpoint_correlations"] = pd.DataFrame([
        dict(metric=m, predictor=p, spearman=stats.spearmanr(ec[p], ec[m])[0],
             p_value=stats.spearmanr(ec[p], ec[m])[1])
        for m in ["roc_auc", "average_precision", "mcc"]
        for p in ["n_labeled", "missing_fraction", "active_prevalence",
                  "n_unique_scaffolds", "scaffold_per_compound", "n_active"]])

    # 8.3 variabilitas
    mr = s3["metrics_repeat"]
    R["variance"] = pd.DataFrame([
        dict(model=mod, metric=m, grand_mean=blk.groupby("endpoint")[m].mean().mean(),
             sd_between_endpoints=blk.groupby("endpoint")[m].mean().std(ddof=1),
             mean_sd_within_endpoint=blk.groupby("endpoint")[m].std(ddof=1).mean())
        for m in ["roc_auc", "average_precision", "balanced_accuracy", "mcc"]
        for mod, blk in mr.groupby("model")])

    # 8.4 ECE + threshold
    print("  8.4 kalibrasi & threshold", flush=True)
    def ece(y, p, nb=10):
        y = np.asarray(y).astype(int); p = np.asarray(p, float)
        e = np.unique(np.quantile(p, np.linspace(0, 1, nb + 1)))
        if len(e) < 3:
            return np.nan
        i = np.clip(np.digitize(p, e[1:-1]), 0, len(e) - 2)
        return float(sum((i == b).mean() * abs(y[i == b].mean() - p[i == b].mean())
                         for b in range(len(e) - 1) if (i == b).sum()))
    R["ece"] = pd.DataFrame([dict(endpoint=t, model=m, ece=ece(d.y_true, d.probability),
                                  brier=((d.probability - d.y_true) ** 2).mean(),
                                  mean_predicted=d.probability.mean(),
                                  observed_prevalence=d.y_true.mean())
                             for (t, m), d in oof.groupby(["endpoint", "model"])])
    ts = []
    for mult in [.6, .8, .9, 1., 1.1, 1.2, 1.5]:
        for t in TOX21_TASKS:
            d = oof[(oof.endpoint == t) & (oof.model == "Ensemble")]
            y = d.y_true.to_numpy(); p = d.probability.to_numpy()
            pr = (p >= np.clip(d.applied_threshold.to_numpy() * mult, 1e-6, 1 - 1e-6)).astype(int)
            ts.append(dict(endpoint=t, multiplier=mult,
                           balanced_accuracy=balanced_accuracy_score(y, pr),
                           mcc=matthews_corrcoef(y, pr),
                           sensitivity=(pr[y == 1] == 1).mean(),
                           specificity=(pr[y == 0] == 0).mean()))
    R["threshold_sensitivity"] = pd.DataFrame(ts)

    # 8.5 false negative
    fs, fd = [], []
    for t in TOX21_TASKS:
        d = oof[(oof.endpoint == t) & (oof.model == "Ensemble")].copy()
        d["margin"] = d.probability - d.applied_threshold
        act = d[d.y_true == 1]; fn = act[act.prediction == 0]
        near = fn[fn.margin > -.05]
        fs.append(dict(endpoint=t, n_active=len(act), n_false_negative=len(fn),
                       false_negative_rate=len(fn) / max(len(act), 1),
                       n_near_miss=len(near), frac_near_miss=len(near) / max(len(fn), 1),
                       median_margin=float(fn.margin.median()) if len(fn) else np.nan,
                       n_scaffolds=int(fn.scaffold.nunique())))
        fd.append(fn.assign(endpoint=t))
    R["false_negative"] = pd.DataFrame(fs)
    fdall = pd.concat(fd, ignore_index=True)
    R["blind_spots"] = (fdall.groupby("scaffold")
                        .agg(n_false_negatives=("endpoint", "size"),
                             n_endpoints=("endpoint", "nunique"))
                        .sort_values("n_false_negatives", ascending=False)
                        .head(25).reset_index())

    # 8.6 AD: Tanimoto per fold + leverage
    print("  8.6 applicability domain", flush=True)
    fpb = (fp_all > 0).astype(np.float32)
    Ft = fpb[ti]; pct = Ft.sum(1)
    strat = []
    for t in TOX21_TASKS:
        mask, y, g = endpoint_data(t)
        rows_idx = np.where(mask)[0]
        d = oof[(oof.endpoint == t) & (oof.model == "Ensemble")].set_index("tox21_row")
        d = d.reindex(rows_idx).dropna(subset=["probability"])
        if d.empty:
            continue
        pos = np.array([int(np.where(rows_idx == i)[0][0]) for i in d.index])
        sp = splits(y, g, N_SPLITS, REPEAT_SEEDS[0])
        nn = np.full(len(d), np.nan)
        for tr, te in sp:
            sel = np.isin(pos, te)
            if not sel.any():
                continue
            A = Ft[rows_idx[pos[sel]]]; B = Ft[rows_idx[tr]]
            I = A @ B.T
            U = A.sum(1)[:, None] + B.sum(1)[None, :] - I
            nn[sel] = np.max(I / np.maximum(U, 1e-9), axis=1)
        d = d.assign(nn=nn).dropna(subset=["nn"])
        q = pd.qcut(d.nn, 4, labels=["Q1", "Q2", "Q3", "Q4"], duplicates="drop")
        for lab, sub in d.groupby(q, observed=True):
            if sub.y_true.nunique() < 2:
                continue
            strat.append(dict(endpoint=t, quartile=str(lab), n=len(sub),
                              mean_similarity=float(sub.nn.mean()),
                              roc_auc=roc_auc_score(sub.y_true, sub.probability),
                              balanced_accuracy=balanced_accuracy_score(sub.y_true, sub.prediction),
                              mcc=matthews_corrcoef(sub.y_true, sub.prediction)))
    R["ad_stratified"] = pd.DataFrame(strat)

    Xt, Xb = desc_all[ti].astype(float), desc_all[bi].astype(float)
    mu, sd = np.nanmean(Xt, 0), np.nanstd(Xt, 0); sd[sd == 0] = 1
    Zt, Zb = (np.nan_to_num(Xt) - mu) / sd, (np.nan_to_num(Xb) - mu) / sd
    inv = np.linalg.pinv(Zt.T @ Zt)
    lev = np.einsum("ij,jk,ik->i", Zb, inv, Zb)
    h_star = 3. * Zt.shape[1] / Zt.shape[0]
    I = fpb[bi] @ Ft.T
    U = fpb[bi].sum(1)[:, None] + pct[None, :] - I
    maxsim_blu = np.max(I / np.maximum(U, 1e-9), axis=1)
    ad = pd.DataFrame(dict(compound_name=blumea["compound_name"].to_numpy(),
                           leverage=lev, h_star=h_star,
                           max_tanimoto=maxsim_blu,
                           distance_to_centroid=np.linalg.norm(Zb, axis=1)))
    ad["outside_leverage"] = ad.leverage > h_star
    ad["outside_tanimoto"] = ad.max_tanimoto < AD_TANIMOTO_CUTOFF
    ad["ad_flag"] = np.where(ad.outside_leverage | ad.outside_tanimoto,
                             "Outside domain", "Inside domain")
    R["applicability_domain"] = ad.sort_values("max_tanimoto")

    # 8.8 koherensi struktural per titik akhir
    #
    #  Menjawab "mengapa SR-MMP unggul dan NR-ER tertinggal" dengan ukuran yang
    #  dihitung dari data, bukan dengan narasi mekanistik. Tiga ukuran:
    #
    #    nn_active      kemiripan Tanimoto rata-rata tiap senyawa aktif ke
    #                   senyawa aktif TERDEKAT lainnya pada titik akhir yang
    #                   sama. Tinggi = aktif-aktif berkerumun secara struktural.
    #    similarity_auc ROC-AUC dari penduga BEBAS MODEL: skor = kemiripan
    #                   maksimum ke senyawa aktif di lipatan latih. Ini batas
    #                   bawah berapa banyak sinyal yang murni berasal dari
    #                   kemiripan struktur, tanpa pembelajaran apa pun.
    #    co_activity    rata-rata fraksi titik akhir LAIN tempat senyawa aktif
    #                   itu juga aktif. Tinggi = kemungkinan sitotoksisitas
    #                   umum; rendah = sinyal khas titik akhir tersebut.
    print("  8.8 koherensi struktural", flush=True)
    koh = []
    for t in TOX21_TASKS:
        mask, y, g = endpoint_data(t)
        rows_idx = np.where(mask)[0]
        F = Ft[rows_idx]
        c = F.sum(1)
        ai = np.where(y == 1)[0]
        if len(ai) < 3:
            continue
        A = F[ai]
        I = A @ A.T
        U = c[ai][:, None] + c[ai][None, :] - I
        S = I / np.maximum(U, 1e-9)
        np.fill_diagonal(S, -1.0)
        nn_act = float(S.max(1).mean())

        # penduga bebas model, lipatan scaffold yang sama dengan protokol utama
        skor = np.full(len(y), np.nan)
        for tr, te in splits(y, g, N_SPLITS, REPEAT_SEEDS[0]):
            at = tr[y[tr] == 1]
            if len(at) == 0:
                continue
            B = F[at]
            I2 = F[te] @ B.T
            U2 = c[te][:, None] + c[at][None, :] - I2
            skor[te] = np.max(I2 / np.maximum(U2, 1e-9), axis=1)
        okk = np.isfinite(skor)
        sim_auc = (roc_auc_score(y[okk], skor[okk])
                   if okk.sum() > 20 and len(np.unique(y[okk])) == 2 else np.nan)

        # ko-aktivitas antar panel
        lain = [u for u in TOX21_TASKS if u != t]
        sub = tox.iloc[rows_idx[ai]][lain]
        frac = []
        for _, r_ in sub.iterrows():
            v = r_.dropna()
            if len(v):
                frac.append(float((v.astype(float) == 1).mean()))
        koh.append(dict(endpoint=t, n_active=int(len(ai)),
                        nn_active_tanimoto=nn_act,
                        similarity_only_auc=sim_auc,
                        co_activity=float(np.mean(frac)) if frac else np.nan))
    koh = pd.DataFrame(koh)
    kin = ec.set_index("endpoint")[["roc_auc", "average_precision",
                                    "active_prevalence"]]
    koh = koh.merge(kin.reset_index(), on="endpoint", how="left")
    R["structural_coherence"] = koh.sort_values("average_precision",
                                                ascending=False)

    def _sprho(a, b):
        m_ = np.isfinite(a) & np.isfinite(b)
        if m_.sum() < 5:
            return np.nan, np.nan
        r_ = stats.spearmanr(a[m_], b[m_])
        return float(r_[0]), float(r_[1])

    def _parsial(a, b, c_):
        """Spearman parsial a~b dengan c_ dikendalikan, lewat residual peringkat."""
        m_ = np.isfinite(a) & np.isfinite(b) & np.isfinite(c_)
        if m_.sum() < 6:
            return np.nan, np.nan
        ra, rb, rc = (stats.rankdata(v[m_]) for v in (a, b, c_))
        Z = np.column_stack([np.ones(len(rc)), rc])
        res = lambda v: v - Z @ np.linalg.lstsq(Z, v, rcond=None)[0]
        r_ = stats.pearsonr(res(ra), res(rb))
        return float(r_[0]), float(r_[1])

    # Prevalensi dan jumlah aktif TIDAK diuji lagi di sini: keduanya sudah
    # diuji di 8.2. Menghitungnya dua kali akan memberi dua tabel dengan rho
    # yang sama tetapi p terkoreksi berbeda, dan itu justru yang membuat
    # naskah tampak tidak konsisten. Di 8.8 keduanya hanya dipakai sebagai
    # peubah kendali untuk korelasi parsial.
    krow = []
    for kin_m in ("roc_auc", "average_precision"):
        for pr in ("nn_active_tanimoto", "similarity_only_auc", "co_activity"):
            a_ = koh[pr].to_numpy(float); b_ = koh[kin_m].to_numpy(float)
            r_, p_ = _sprho(a_, b_)
            rp, pp = _parsial(a_, b_, koh["active_prevalence"].to_numpy(float))
            krow.append(dict(source="8.8", metric=kin_m, predictor=pr,
                             n_endpoints=int((np.isfinite(a_) & np.isfinite(b_)).sum()),
                             spearman=r_, p_value=p_,
                             partial_spearman_given_prevalence=rp,
                             partial_p_value=pp))

    # Satu keluarga, satu koreksi multiplisitas. Baris 8.2 untuk kedua ukuran
    # yang sama digabung ke sini, sehingga hanya ada SATU tabel p terkoreksi
    # yang boleh dikutip naskah. Tabel 8.2 tetap menyimpan p mentahnya.
    _e22 = R["endpoint_correlations"]
    _e22 = _e22[_e22.metric.isin(["roc_auc", "average_precision"])].copy()
    _e22["source"] = "8.2"
    _e22["n_endpoints"] = len(ec)
    kc = pd.concat([_e22, pd.DataFrame(krow)], ignore_index=True)
    kc["p_holm"] = holm(kc.p_value.fillna(1).to_numpy())
    kc["significant_holm"] = kc.p_holm < .05
    kc = kc.sort_values(["metric", "p_value"]).reset_index(drop=True)
    R["structural_correlations"] = kc
    print(f"  satu keluarga Holm: {len(kc)} uji "
          f"({len(_e22)} dari 8.2 + {len(krow)} dari 8.8)", flush=True)
    print(kc.round(4).to_string(index=False), flush=True)

    # 8.7 pembobotan skor prioritas
    print("  8.7 skema pembobotan", flush=True)
    bp = s5["blumea_prob"]
    P = bp[TOX21_TASKS].to_numpy()
    auc_e = ec.set_index("endpoint")["roc_auc"].reindex(TOX21_TASKS).to_numpy()
    prev = ec.set_index("endpoint")["active_prevalence"].reindex(TOX21_TASKS).to_numpy()
    schemes = {"equal": np.ones(len(TOX21_TASKS)), "by_roc_auc": auc_e.copy(),
               "by_auc_above_chance": np.clip(auc_e - .5, 0, None),
               "inverse_prevalence": 1 / np.clip(prev, 1e-6, None),
               "reliable_only_auc_gt_075": (auc_e > .75).astype(float)}
    W = pd.DataFrame({"compound_name": bp["compound_name"]})
    for n, w in schemes.items():
        w = np.asarray(w, float)
        if w.sum() == 0:
            continue
        W[n] = 100 * (P @ (w / w.sum()))
        W["rank_" + n] = W[n].rank(ascending=False, method="min").astype(int)
    cols = [c for c in schemes if c in W]
    R["weighting"] = W.sort_values("equal", ascending=False).reset_index(drop=True)
    R["weighting_agreement"] = pd.DataFrame([
        dict(a=a, b=b, spearman=stats.spearmanr(W[a], W[b])[0],
             kendall=stats.kendalltau(W[a], W[b])[0],
             top5_overlap=len(set(W.nlargest(5, a).compound_name)
                              & set(W.nlargest(5, b).compound_name)))
        for i, a in enumerate(cols) for b in cols[i + 1:]])

    # 8.9 dekomposisi skor prioritas
    #
    #  Skor = 100 x rata-rata probabilitas terkalibrasi atas 12 titik akhir,
    #  jadi setiap titik akhir menyumbang tepat 100*p_t/12 poin. Tabel ini
    #  memperlihatkan dari mana angka peringkat teratas berasal, sehingga
    #  pembaca dapat menilai apakah skor digerakkan oleh titik akhir yang
    #  modelnya andal atau oleh titik akhir yang lemah.
    print("  8.9 dekomposisi skor", flush=True)
    kontrib = 100.0 * P / len(TOX21_TASKS)
    dek = pd.DataFrame(kontrib, columns=TOX21_TASKS)
    dek.insert(0, "compound_name", bp["compound_name"].to_numpy())
    dek["score_total"] = kontrib.sum(1)
    dek = dek.sort_values("score_total", ascending=False).reset_index(drop=True)
    dek["rank"] = np.arange(1, len(dek) + 1)
    R["score_decomposition"] = dek

    andal = [t for t in TOX21_TASKS
             if float(ec.set_index("endpoint").loc[t, "roc_auc"]) > 0.75]
    sh = pd.DataFrame({"compound_name": dek["compound_name"],
                       "rank": dek["rank"],
                       "score_total": dek["score_total"]})
    sh["from_reliable_endpoints"] = dek[andal].sum(1) if andal else np.nan
    sh["share_reliable"] = sh["from_reliable_endpoints"] / sh["score_total"]
    top1 = dek[TOX21_TASKS].to_numpy().argmax(1)
    sh["largest_contributor"] = [TOX21_TASKS[i] for i in top1]
    sh["largest_contribution"] = dek[TOX21_TASKS].to_numpy().max(1)
    sh["share_largest"] = sh["largest_contribution"] / sh["score_total"]
    R["score_decomposition_summary"] = sh
    print(f"    titik akhir andal (ROC-AUC>0,75): {len(andal)} dari "
          f"{len(TOX21_TASKS)}", flush=True)
    print(sh.head(8).round(3).to_string(index=False), flush=True)

    # 8.10 dampak eksklusi terhadap cakupan ruang kimia
    #
    #  Reviewer menerima eksklusinya tetapi meminta dampaknya dibahas lebih
    #  tuntas. Yang dihitung di sini, bukan dinyatakan:
    #    - berapa struktur, label, dan label aktif yang hilang, sebagai
    #      proporsi terhadap himpunan yang dipakai
    #    - apakah scaffold tiap struktur yang dibuang masih terwakili oleh
    #      struktur lain yang tetap dipertahankan; kalau ya, cakupan scaffold
    #      tidak berkurang meski strukturnya hilang
    #    - berapa kemiripan maksimum senyawa Blumea yang bersangkutan SETELAH
    #      eksklusi, berikut status domain keberlakuan dan peringkat akhirnya
    #
    #  Butir ketiga yang paling penting: justru untuk senyawa inilah eksklusi
    #  mengubah prediksi dari pencocokan menjadi ekstrapolasi sungguhan.
    print("  8.10 dampak eksklusi", flush=True)
    _oa = s1.get("overlap_audit")
    if _oa is not None and len(_oa):
        _oa = _oa.copy()
        _kol = [c for c in TOX21_TASKS if c in _oa.columns]
        _oa["n_label"] = _oa[_kol].notna().sum(axis=1)
        _oa["n_active"] = (_oa[_kol] == 1).sum(axis=1)
        _scaf_tersisa = tox["scaffold"].value_counts()
        _oa["scaffold_retained"] = _oa["scaffold"].isin(_scaf_tersisa.index)
        _oa["n_retained_sharing_scaffold"] = (
            _oa["scaffold"].map(_scaf_tersisa).fillna(0).astype(int))
        # Dijaga: satu KeyError di sini akan menjatuhkan seluruh Tahap 8,
        # dan tahap itu dua puluh menit. Kolom yang sumbernya tidak ada
        # cukup dikosongkan.
        _ad = R.get("applicability_domain", pd.DataFrame(
            columns=["compound_name", "max_tanimoto", "ad_flag"])).copy()
        _ad = (_ad.set_index("compound_name") if "compound_name" in _ad.columns
               else _ad)
        _st = (s5.get("stability", pd.DataFrame(columns=["compound_name"]))
               .reset_index(drop=True))
        _st = _st.assign(rank_final=np.arange(1, len(_st) + 1)).set_index("compound_name")
        for _c, _src, _kk in (("max_tanimoto_after", _ad, "max_tanimoto"),
                              ("ad_flag_after", _ad, "ad_flag"),
                              ("rank_final", _st, "rank_final"),
                              ("score_mean", _st, "score_mean")):
            _oa[_c] = _oa["blumea_compound"].map(
                _src[_kk] if _kk in _src.columns else pd.Series(dtype=float))
        R["exclusion_impact"] = _oa[[
            "blumea_compound", "exclusion_reason", "scaffold", "n_label",
            "n_active", "scaffold_retained", "n_retained_sharing_scaffold",
            "max_tanimoto_after", "ad_flag_after", "rank_final", "score_mean"]]

        _n_lab_total = int(tox[TOX21_TASKS].notna().sum().sum())
        _n_act_total = int((tox[TOX21_TASKS] == 1).sum().sum())
        _n_awal = int(s1.get("n_before", len(tox) + len(_oa)))
        R["exclusion_impact_summary"] = pd.DataFrame([dict(
            n_structures_removed=len(_oa),
            n_structures_before=_n_awal,
            pct_structures_removed=round(100 * len(_oa) / max(_n_awal, 1), 4),
            n_blumea_compounds_affected=int(_oa.blumea_compound.nunique()),
            n_labels_removed=int(_oa.n_label.sum()),
            pct_labels_removed=round(
                100 * int(_oa.n_label.sum()) / max(_n_lab_total + int(_oa.n_label.sum()), 1), 4),
            n_active_labels_removed=int(_oa.n_active.sum()),
            pct_active_labels_removed=round(
                100 * int(_oa.n_active.sum()) / max(_n_act_total + int(_oa.n_active.sum()), 1), 4),
            n_scaffolds_affected=int(_oa.scaffold.nunique()),
            n_scaffolds_lost_entirely=int((~_oa.scaffold_retained).sum()))])
        print(R["exclusion_impact"].round(3).to_string(index=False), flush=True)
        print(R["exclusion_impact_summary"].T.to_string(), flush=True)
    else:
        print("    overlap_audit tidak tersedia; dilewati.")

    # 8.11 keluasan aktivitas: prediksi dibandingkan dengan yang TERAMATI
    #
    #  Penelaah menanyakan apakah senyawa peringkat teratas yang ditandai
    #  aktif di banyak titik akhir menunjukkan pengikat promiskuitas atau
    #  artefak metodologis. Pertanyaan itu sebagian dapat dijawab dengan
    #  data, karena promiskuitas adalah sifat yang TERAMATI pada label
    #  Tox21, bukan semata hipotesis.
    #
    #  Yang dihitung:
    #    1. sebaran jumlah titik akhir aktif per senyawa Tox21 yang nyata
    #    2. jumlah titik akhir yang ditandai bagi tiap senyawa Blumea, dan
    #       persentil angka itu di dalam sebaran yang teramati
    #    3. keluasan teramati dari tetangga Tox21 terdekatnya
    #
    #  Kalau keluasan yang diprediksi berada di dalam rentang yang memang
    #  teramati, dan tetangga terdekatnya memang berperilaku demikian, maka
    #  model mereproduksi pola yang ada di label - bukan mengarang keluasan
    #  yang tidak dimiliki data mana pun. Itu MENYINGKIRKAN artefak model.
    #  Ia tidak memisahkan promiskuitas sejati dari interferensi asai; hanya
    #  percobaan berkendali yang bisa, dan naskah menyatakan demikian.
    print("  8.11 keluasan aktivitas", flush=True)
    _lab = tox[TOX21_TASKS].notna().to_numpy()
    _akt = (tox[TOX21_TASKS] == 1).to_numpy()
    _n_akt_sen = _akt.sum(axis=1)
    _n_lab_sen = _lab.sum(axis=1)
    _punya = _n_lab_sen >= 6          # minimal separuh panel berlabel
    # Penyebutnya HARUS senyawa yang masuk hitungan, bukan seluruh senyawa.
    # Kalau tidak, kolom n_compounds dan fraction memakai penyebut berbeda
    # di dalam satu tabel yang sama.
    _n_punya = int(_punya.sum())
    R["observed_breadth"] = pd.DataFrame(
        [dict(n_active_endpoints=int(k),
              n_compounds=int(((_n_akt_sen == k) & _punya).sum()),
              fraction_of_included=float(((_n_akt_sen == k) & _punya).sum()
                                         / max(_n_punya, 1)))
         for k in range(len(TOX21_TASKS) + 1)])
    R["observed_breadth"].attrs["n_included"] = _n_punya
    _obs = np.sort(_n_akt_sen[_punya])
    print(f"    senyawa Tox21 dengan >= 6 label: {int(_punya.sum())}; "
          f"maks titik akhir aktif teramati: {int(_obs.max())}; "
          f"persentil 99: {int(np.percentile(_obs, 99))}", flush=True)

    # ambang per titik akhir = median ambang yang dipakai pada OOF ensemble
    _thr = (oof[oof.model == "Ensemble"].groupby("endpoint")["applied_threshold"]
            .median().reindex(TOX21_TASKS).to_numpy())
    _bp = s5["blumea_prob"]
    _P = _bp[TOX21_TASKS].to_numpy()
    _flag = (_P >= _thr[None, :])
    _n_flag = _flag.sum(axis=1)

    # tetangga Tox21 terdekat tiap senyawa Blumea
    _Fb = fpb[bi]
    _I = _Fb @ Ft.T
    _U = _Fb.sum(1)[:, None] + Ft.sum(1)[None, :] - _I
    _S = _I / np.maximum(_U, 1e-9)
    _K = 10
    _idx = np.argsort(-_S, axis=1)[:, :_K]
    _nb_breadth = np.array([_n_akt_sen[r][_punya[r]].mean()
                            if _punya[r].any() else np.nan for r in _idx])
    _nb_sim = np.take_along_axis(_S, _idx, axis=1).mean(axis=1)

    R["predicted_breadth"] = pd.DataFrame(dict(
        compound_name=_bp["compound_name"].to_numpy(),
        n_endpoints_flagged=_n_flag,
        percentile_in_observed=[float((_obs <= v).mean() * 100) for v in _n_flag],
        n_tox21_at_least_this_broad=[int((_obs >= v).sum()) for v in _n_flag],
        mean_similarity_10nn=_nb_sim,
        mean_observed_breadth_10nn=_nb_breadth,
    )).merge(s5["stability"][["compound_name", "score_mean"]], on="compound_name",
             how="left").sort_values("score_mean", ascending=False).reset_index(drop=True)
    print(R["predicted_breadth"].head(6).round(3).to_string(index=False), flush=True)

    # 8.12 metrik per model pada estimator yang SAMA dengan uji signifikansi
    #
    #  Tabel kinerja naskah melaporkan ROC-AUC, average precision, balanced
    #  accuracy, MCC, dan Brier untuk tiap model. Dua dari itu berasal dari
    #  tempat berbeda kalau tidak hati-hati: ROC-AUC dan AP dapat dibaca dari
    #  uji signifikansi, yang memakai probabilitas luar-lipatan RATA-RATA tiga
    #  pengulangan, sementara balanced accuracy dan MCC selama ini hanya
    #  tersedia dari rata-rata metrik PER pengulangan. Keduanya estimator yang
    #  berbeda dan memberi angka berbeda, sehingga satu tabel yang mencampur
    #  keduanya tidak konsisten.
    #
    #  Blok ini menghitung SELURUH metrik dari satu estimator, yaitu yang juga
    #  dipakai uji signifikansi, untuk setiap model di Tahap 3 dan Tahap 3B.
    print("  8.12 metrik per model, estimator tunggal", flush=True)
    _src = oof if (s3b is None or not len(s3b.get("oof", []))) else pd.concat(
        [oof, s3b["oof"]], ignore_index=True)
    _rows = []
    for (_m, _t), _d in _src.groupby(["model", "endpoint"]):
        _y = _d.y_true.to_numpy().astype(int)
        _p = _d.probability.to_numpy()
        _pr = _d.prediction.to_numpy().astype(int)
        if len(np.unique(_y)) < 2:
            continue
        _rows.append(dict(model=_m, endpoint=_t, n=len(_y), **metrics(_y, _p, _pr)))
    _pm = pd.DataFrame(_rows)
    R["model_metrics_per_endpoint"] = _pm
    R["model_metrics_summary"] = (
        _pm.groupby("model")
        .agg(roc_auc=("roc_auc", "mean"), roc_auc_sd=("roc_auc", "std"),
             average_precision=("average_precision", "mean"),
             average_precision_sd=("average_precision", "std"),
             balanced_accuracy=("balanced_accuracy", "mean"),
             balanced_accuracy_sd=("balanced_accuracy", "std"),
             mcc=("mcc", "mean"), mcc_sd=("mcc", "std"),
             accuracy=("accuracy", "mean"), brier=("brier", "mean"),
             sensitivity=("sensitivity", "mean"),
             specificity=("specificity", "mean"),
             n_endpoints=("roc_auc", "size"))
        .sort_values("roc_auc", ascending=False).reset_index())
    print(R["model_metrics_summary"][
        ["model", "roc_auc", "average_precision", "balanced_accuracy",
         "mcc", "brier"]].round(4).to_string(index=False), flush=True)
    print("    (estimator: probabilitas luar-lipatan rata-rata tiga pengulangan,"
          "\\n     sama dengan yang dipakai Tahap 8.1; satu estimator untuk"
          " seluruh tabel)", flush=True)

    save("s8_posthoc", R)
    print("  selesai")

s8 = load("s8_posthoc")


# ==============================================================================
# TAHAP 9 — FINE-TUNE CHEMBERTA (OPSIONAL, PERLU GPU)                     [A2]
# ==============================================================================
if STAGES[9] and not done("s9_finetune"):
    banner("TAHAP 9 — fine-tune ChemBERTa (perlu GPU)")
    # Impor dijaga: tahap ini sekarang menyala secara bawaan, jadi lingkungan
    # tanpa torch atau transformers tidak boleh menjatuhkan seluruh run di
    # ujung, setelah belasan jam. Dilewati tanpa menyimpan checkpoint.
    try:
        import torch
        from torch.utils.data import DataLoader, TensorDataset
        from transformers import AutoTokenizer, AutoModelForSequenceClassification
        _ada_torch = True
    except Exception as _e9:
        print(f"  torch/transformers tidak tersedia ({_e9}) — Tahap 9 dilewati.")
        print("  pasang lalu jalankan ulang sel ini di runtime GPU.")
        _ada_torch = False
    if _ada_torch and not torch.cuda.is_available():
        # JANGAN simpan checkpoint kosong di sini. Kalau disimpan, done()
        # menjadi True dan tahap ini akan dilewati selamanya, termasuk nanti
        # ketika runtime GPU dipakai. Cukup dilewati tanpa jejak.
        print("  TIDAK ADA GPU — dilewati tanpa menyimpan checkpoint.")
        print("  Jalankan sel ini lagi di runtime GPU untuk mengisi Tahap 9.")
    elif _ada_torch:
        dev = torch.device("cuda")
        tok = AutoTokenizer.from_pretrained(CHEMBERTA_MODEL)
        # SELURUH 12 titik akhir, bukan 3 terbesar. Butir reviewer tentang
        # beku versus fine-tune adalah salah satu jawaban terkuat naskah, dan
        # 3 titik akhir jauh kurang meyakinkan daripada 12. Diurutkan dari
        # yang terbesar supaya bila sesi terputus, yang paling informatif
        # sudah selesai lebih dulu; checkpoint disimpan per titik akhir.
        big = sorted(TOX21_TASKS, key=lambda t: -int((tox[t] == 1).sum()))

        def embed_ft(model, smiles, bs=64):
            """Mean-pooled embedding dari encoder yang SUDAH di-fine-tune.

            Dipakai untuk menyetarakan kepala klasifikasi. Tanpa ini,
            perbandingannya mencampur dua perubahan sekaligus: bobot encoder
            DAN kepala (XGBoost versus softmax linear), sehingga tidak bisa
            disimpulkan apa pun tentang representasinya.
            """
            base = getattr(model, "base_model", model)
            out = []
            with torch.inference_mode():
                for i in range(0, len(smiles), bs):
                    t_ = tok(smiles[i:i + bs], padding=True, truncation=True,
                             max_length=256, return_tensors="pt")
                    t_ = {k: v.to(dev) for k, v in t_.items()}
                    h = base(**t_).last_hidden_state
                    m_ = t_["attention_mask"].unsqueeze(-1).expand(h.size()).float()
                    out.append(((h * m_).sum(1) / m_.sum(1).clamp(min=1e-9))
                               .cpu().numpy())
            return np.vstack(out).astype(np.float32)

        rows = []
        for t_i9, task in enumerate(big):
            if done(f"s9_ep{t_i9:02d}"):
                print(f"  [{t_i9+1}/12] {task} — sudah ada, dilewati", flush=True)
                continue
            print(f"  [{t_i9+1}/12] {task}  ({(time.time()-T0)/60:.0f} mnt)",
                  flush=True)
            mask, y, g = endpoint_data(task)
            smi = tox.loc[mask, "canonical_smiles"].tolist()
            tr, te = splits(y, g, N_SPLITS, SEED)[0]
            enc = tok([smi[i] for i in tr], padding="max_length", truncation=True,
                      max_length=256, return_tensors="pt")
            dl = DataLoader(TensorDataset(enc["input_ids"], enc["attention_mask"],
                                          torch.tensor(y[tr])), batch_size=32, shuffle=True)
            mdl = AutoModelForSequenceClassification.from_pretrained(
                CHEMBERTA_MODEL, num_labels=2).to(dev)
            opt = torch.optim.AdamW(mdl.parameters(), lr=2e-5)
            w = torch.tensor([1., (y[tr] == 0).sum() / max((y[tr] == 1).sum(), 1)],
                             dtype=torch.float32).to(dev)
            lossf = torch.nn.CrossEntropyLoss(weight=w)
            mdl.train()
            for ep in range(3):
                for ii, am, yy in dl:
                    opt.zero_grad()
                    out = mdl(input_ids=ii.to(dev), attention_mask=am.to(dev))
                    lossf(out.logits, yy.long().to(dev)).backward(); opt.step()
                print(f"    {task} epoch {ep+1}", flush=True)
            mdl.eval()
            enc2 = tok([smi[i] for i in te], padding="max_length", truncation=True,
                       max_length=256, return_tensors="pt")
            ps = []
            with torch.inference_mode():
                for i in range(0, len(te), 64):
                    o = mdl(input_ids=enc2["input_ids"][i:i+64].to(dev),
                            attention_mask=enc2["attention_mask"][i:i+64].to(dev))
                    ps.append(torch.softmax(o.logits, -1)[:, 1].cpu().numpy())
            pf = np.concatenate(ps)        # fine-tune ujung-ke-ujung

            # --- (1) jalur BEKU: embedding beku + RDKit -> XGBoost
            Xc = X_tox_c[mask]
            isp = splits(y[tr], g[tr], INNER_SPLITS, SEED); b_, c_ = isp[0]
            pfz, _, _ = fit_fold(Xc[tr], y[tr], Xc[te], b_, c_, SEED)

            # --- (2) jalur FINE-TUNE DENGAN KEPALA SETARA:
            #         embedding dari encoder yang sudah di-fine-tune + RDKit
            #         -> XGBoost yang SAMA, lipatan sama, kalibrasi sama.
            #         Satu-satunya yang berbeda dari (1) adalah bobot encoder.
            emb_ft = embed_ft(mdl, smi)
            Xft = np.hstack([emb_ft, desc_t[mask]])
            pft, _, _ = fit_fold(Xft[tr], y[tr], Xft[te], b_, c_, SEED)

            # Ketiganya dinilai pada senyawa uji yang sama persis, jadi DeLong
            # berlaku langsung. Yang menjawab pertanyaan representasi adalah
            # (2) versus (1); (pf) dilaporkan terpisah sebagai klasifikator
            # ujung-ke-ujung, yang kepalanya TIDAK setara.
            _, _, z_e2e, p_e2e = delong(y[te], pf, pfz)
            _, _, z_rep, p_rep = delong(y[te], pft, pfz)
            rows.append(dict(
                endpoint=task,
                n_test=int(len(te)), n_active_test=int(y[te].sum()),
                # kepala setara: inilah perbandingan representasi
                roc_auc_frozen_xgb=roc_auc_score(y[te], pfz),
                roc_auc_finetuned_xgb=roc_auc_score(y[te], pft),
                ap_frozen_xgb=average_precision_score(y[te], pfz),
                ap_finetuned_xgb=average_precision_score(y[te], pft),
                delong_z_representation=z_rep, delong_p_representation=p_rep,
                # kepala TIDAK setara: klasifikator fine-tune ujung-ke-ujung
                roc_auc_finetuned_e2e=roc_auc_score(y[te], pf),
                ap_finetuned_e2e=average_precision_score(y[te], pf),
                delong_z_endtoend=z_e2e, delong_p_endtoend=p_e2e))
            save(f"s9_ep{t_i9:02d}", dict(baris=rows[-1], n_struktur=len(tox)))
            del mdl; torch.cuda.empty_cache()

        bag9 = [load(f"s9_ep{i:02d}") for i in range(len(big))]
        bag9 = [b for b in bag9 if b is not None]
        if any(b["n_struktur"] != len(tox) for b in bag9):
            raise SystemExit("BERHENTI: checkpoint s9_ep* dari dataset berbeda. "
                             "Hapus checkpoints/s9_ep*.pkl lalu jalankan ulang.")
        s9df = pd.DataFrame([b["baris"] for b in bag9])
        if len(s9df) < len(big):
            print(f"  PERINGATAN: baru {len(s9df)}/{len(big)} titik akhir "
                  "selesai. Jalankan ulang sel ini untuk melanjutkan; "
                  "s9_finetune belum disimpan.")
        else:
            save("s9_finetune", s9df)
            d_rep = (s9df.roc_auc_finetuned_xgb - s9df.roc_auc_frozen_xgb)
            print(s9df.round(4).to_string(index=False))
            print(f"\n  KEPALA SETARA (yang menjawab pertanyaan representasi):")
            print(f"    fine-tune menang di {int((d_rep > 0).sum())}/{len(s9df)} "
                  f"titik akhir, selisih rata-rata {d_rep.mean():+.4f}")
            zz = stouffer(s9df.delong_z_representation.to_numpy(), 0.2)
            print(f"    Stouffer r=0,2: z={zz[0]:.3f}  p dua sisi={zz[1]:.3e}")


# ==============================================================================
# EKSPOR
# ==============================================================================
banner("EKSPOR HASIL")
sheets = {}
s1b = load("s1_data")
sheets["Audit Eksklusi"] = s1b["overlap_audit"]
sheets["Ringkasan Eksklusi"] = pd.DataFrame([{
    "tox21_valid_unik": s1b["n_before"],
    "dibuang_smiles_identik": s1b["n_removed_iso"],
    "dibuang_stereoisomer_baru": s1b["n_removed_stereo_only"],
    "tox21_dipakai": s1b["n_after"],
    "persen_dibuang": round(100 * (s1b["n_before"] - s1b["n_after"]) / s1b["n_before"], 4),
    "n_blumea": len(blumea)}])
if s3:
    sheets["Metrik Per Repeat"] = s3["metrics_repeat"]
    sheets["Threshold"] = s3["thresholds"]
    # Rata-rata PER TITIK AKHIR, bukan dikumpulkan jadi satu daftar. Mengumpulkan
    # 12 titik akhir dengan prevalensi berbeda ke satu ROC-AUC bukan besaran yang
    # dilaporkan naskah, dan itu salah satu sumber angka yang dulu tidak bisa
    # dilacak. Di sini keduanya dihitung dan diberi nama berbeda.
    _mr = s3["metrics_repeat"]
    _per_ep = _mr.groupby(["model", "endpoint"]).mean(numeric_only=True).reset_index()
    sheets["Perbandingan Model"] = (
        _per_ep.groupby("model")
        .agg(mean_roc_auc=("roc_auc", "mean"), sd_roc_auc=("roc_auc", "std"),
             mean_ap=("average_precision", "mean"), sd_ap=("average_precision", "std"),
             mean_accuracy=("accuracy", "mean"),
             mean_balanced_accuracy=("balanced_accuracy", "mean"),
             mean_mcc=("mcc", "mean"), mean_brier=("brier", "mean"),
             n_endpoints=("roc_auc", "size"))
        .sort_values("mean_roc_auc", ascending=False).reset_index())
    sheets["Perbandingan Model Pooled"] = (
        s3["oof"].groupby("model")
        .apply(lambda d: pd.Series(dict(
            roc_auc_pooled=roc_auc_score(d.y_true, d.probability),
            ap_pooled=average_precision_score(d.y_true, d.probability))),
            include_groups=False).reset_index())
if s3b is not None and len(s3b.get("metrics_repeat", [])):
    sheets["Garis Dasar Per Repeat"] = s3b["metrics_repeat"]
    sheets["Garis Dasar Ringkasan"] = (
        s3b["metrics_repeat"].groupby("model")
        .agg(mean_roc_auc=("roc_auc", "mean"), sd_roc_auc=("roc_auc", "std"),
             mean_ap=("average_precision", "mean"),
             mean_balanced_accuracy=("balanced_accuracy", "mean"),
             mean_mcc=("mcc", "mean"), mean_accuracy=("accuracy", "mean"),
             mean_brier=("brier", "mean"))
        .sort_values("mean_roc_auc", ascending=False).reset_index())
if s4:
    sheets["Ablasi"] = s4["ablation"]
    # Ringkasan ini yang dibaca untuk mengisi tabel naskah, jadi ia harus
    # memuat SELURUH metrik yang mungkin dikutip. Versi lama hanya empat
    # kolom, dan itulah sebabnya akurasi, balanced accuracy, dan Brier
    # dahulu harus direkonstruksi terpisah dari matriks konfusi.
    sheets["Ablasi Ringkasan"] = (
        s4["ablation"].groupby("variant")
        .agg(mean_roc_auc=("roc_auc", "mean"), sd_roc_auc=("roc_auc", "std"),
             mean_ap=("average_precision", "mean"), sd_ap=("average_precision", "std"),
             mean_accuracy=("accuracy", "mean"),
             mean_balanced_accuracy=("balanced_accuracy", "mean"),
             mean_mcc=("mcc", "mean"), mean_f1=("f1", "mean"),
             mean_sensitivity=("sensitivity", "mean"),
             mean_specificity=("specificity", "mean"),
             mean_precision=("precision", "mean"),
             mean_brier=("brier", "mean"), n_endpoints=("roc_auc", "size"))
        .sort_values("mean_roc_auc", ascending=False).reset_index())
    sheets["Efek Kalibrasi"] = s4["calibration_effect"]
    sheets["Nested CV"] = s4["nested_cv"]
if s5:
    sheets["Stabilitas Ranking"] = s5["stability"]
    sheets["Kesesuaian Seed"] = s5["agreement"]
    sheets["Probabilitas Blumea"] = s5["blumea_prob"]
if s6:
    sheets["Kebocoran Performa"] = s6["performance"]
    sheets["Kebocoran Ranking"] = s6["comparison"]
    sheets["Kebocoran Ringkasan"] = s6["agreement"]
if s7 is not None and len(s7):
    sheets["Holdout Kimia Terjauh"] = s7
if s8:
    for k, v in s8.items():
        if isinstance(v, pd.DataFrame):
            sheets[k[:31].replace("_", " ").title()] = v
s9 = load("s9_finetune")
if s9 is not None and len(s9):
    sheets["Fine-tune ChemBERTa"] = s9

# ==============================================================================
# AUDIT KONSISTENSI — setiap angka harus berasal dari 7.817 struktur
# ==============================================================================
banner("AUDIT KONSISTENSI DATASET")
_n_label = {t: int(tox[t].notna().sum()) for t in TOX21_TASKS}
_n_aktif = {t: int((tox[t] == 1).sum()) for t in TOX21_TASKS}
audit_rows = [dict(sumber="tox (struktur dipakai)", satuan="baris",
                   diharapkan=N_STRUKTUR_SAHIH, teramati=len(tox),
                   cocok=len(tox) == N_STRUKTUR_SAHIH)]
for _nm, _M in (("Morgan + RDKit (X_tox_m)", X_tox_m),
                ("ChemBERTa + RDKit (X_tox_c)", X_tox_c),
                ("Morgan saja (fp_t)", fp_t),
                ("ChemBERTa saja (emb_t)", emb_t)):
    audit_rows.append(dict(sumber=f"matriks fitur: {_nm}", satuan="baris",
                           diharapkan=N_STRUKTUR_SAHIH, teramati=len(_M),
                           cocok=len(_M) == N_STRUKTUR_SAHIH))
audit_rows.append(dict(sumber="matriks fitur Blumea (X_blu_m)", satuan="baris",
                       diharapkan=len(blumea), teramati=len(X_blu_m),
                       cocok=len(X_blu_m) == len(blumea)))


def _periksa_oof(nama, df):
    if df is None or not len(df):
        return
    mx = int(df.tox21_row.max())
    audit_rows.append(dict(sumber=f"{nama}: tox21_row maks", satuan="indeks",
                           diharapkan=N_STRUKTUR_SAHIH - 1, teramati=mx,
                           cocok=mx <= N_STRUKTUR_SAHIH - 1))
    for mod, blk in df.groupby("model"):
        salah = [t for t, b2 in blk.groupby("endpoint")
                 if b2.tox21_row.nunique() != _n_label[t]]
        audit_rows.append(dict(sumber=f"{nama}: n per titik akhir [{mod}]",
                               satuan="titik akhir cocok",
                               diharapkan=len(TOX21_TASKS),
                               teramati=len(TOX21_TASKS) - len(salah),
                               cocok=not salah))

_periksa_oof("Tahap 3 OOF", s3["oof"] if s3 else None)
_periksa_oof("Tahap 3B OOF", s3b["oof"] if s3b else None)

if s4 and len(s4.get("ablation", [])):
    ab = s4["ablation"]
    if {"tn", "fp", "fn", "tp"} <= set(ab.columns):
        salah = [(v, t) for (v, t), b2 in ab.groupby(["variant", "endpoint"])
                 if int(b2[["tn", "fp", "fn", "tp"]].to_numpy().sum()) != _n_label[t]]
        audit_rows.append(dict(sumber="Tahap 4 ablasi: n dari matriks konfusi",
                               satuan="sel cocok",
                               diharapkan=ab.groupby(["variant", "endpoint"]).ngroups,
                               teramati=ab.groupby(["variant", "endpoint"]).ngroups - len(salah),
                               cocok=not salah))

# SMOTE-ENN bergantung pada imbalanced-learn. Kalau paketnya tidak ada atau
# IKUT_SMOTEENN dimatikan, varian itu hilang TANPA SUARA, dan naskah akan
# mengutip pembanding yang tidak ada di arsip. Audit memeriksanya di sini,
# sekaligus setiap varian lain yang mungkin gugur di tengah jalan.
if s4 and len(s4.get("ablation", [])):
    _ada_var = set(s4["ablation"].variant.unique())
    _wajib = {"Morgan only (no RDKit)", "ChemBERTa only (no RDKit)",
              "Morgan + RDKit", "ChemBERTa + RDKit",
              "XGBoost, no class weighting", "XGBoost, scale_pos_weight",
              "XGBoost, focal loss", "SMOTE-ENN resampling"}
    _hilang = sorted(_wajib - _ada_var)
    audit_rows.append(dict(sumber="Tahap 4: varian penanganan imbalance",
                           satuan="varian ada",
                           diharapkan=len(_wajib),
                           teramati=len(_wajib) - len(_hilang),
                           cocok=not _hilang))
    if _hilang:
        print(f"  VARIAN HILANG: {_hilang}")
        print("    SMOTE-ENN perlu imbalanced-learn dan IKUT_SMOTEENN=True.")
        print("    Tanpa varian ini, butir reviewer tentang SMOTE tidak terjawab")
        print("    oleh hasil, hanya oleh argumen. Pasang paketnya, hapus")
        print("    checkpoints/s4_ablation.pkl dan s4_ep*.pkl, lalu ulangi Tahap 4.")

if s8 and "significance" in s8 and "n_evaluated" in s8["significance"].columns:
    sg = s8["significance"]
    salah = [t for t, b2 in sg.groupby("endpoint")
             if int(b2.n_evaluated.max()) != _n_label[t]]
    audit_rows.append(dict(sumber="Tahap 8.1 uji signifikansi: n dinilai",
                           satuan="titik akhir cocok",
                           diharapkan=len(TOX21_TASKS),
                           teramati=len(TOX21_TASKS) - len(salah), cocok=not salah))

if s3b is not None and len(s3b.get("oof", [])):
    _dasar_ada = set(s3b["oof"].model.unique())
    _dasar_wajib = {nm for nm, _ in GARIS_DASAR}
    _dasar_hilang = sorted(_dasar_wajib - _dasar_ada)
    audit_rows.append(dict(sumber="Tahap 3B: garis dasar", satuan="pembelajar ada",
                           diharapkan=len(_dasar_wajib),
                           teramati=len(_dasar_wajib) - len(_dasar_hilang),
                           cocok=not _dasar_hilang))
    if _dasar_hilang:
        print(f"  GARIS DASAR HILANG: {_dasar_hilang}")

if s5 and len(s5.get("blumea_prob", [])):
    nb = len(s5["blumea_prob"])
    audit_rows.append(dict(sumber="Tahap 5: senyawa Blumea", satuan="baris",
                           diharapkan=len(blumea), teramati=nb,
                           cocok=nb == len(blumea)))

AUDIT_DF = pd.DataFrame(audit_rows)
AUDIT_DF["cocok"] = AUDIT_DF["cocok"].astype(bool)
sheets["Audit Konsistensi"] = AUDIT_DF
sheets["Jumlah Label Per Titik Akhir"] = pd.DataFrame(
    [dict(endpoint=t, n_labeled=_n_label[t], n_active=_n_aktif[t],
          active_prevalence=_n_aktif[t] / _n_label[t]) for t in TOX21_TASKS])
print(AUDIT_DF.to_string(index=False))
if AUDIT_DF["cocok"].all():
    print(f"\n  LULUS — seluruh keluaran konsisten pada {N_STRUKTUR_SAHIH} struktur.\n")
else:
    print("\n  GAGAL — baris di atas yang cocok=False berasal dari himpunan lain.")
    print("  Hapus checkpoint tahap tersebut dan jalankan ulang sebelum "
          "angkanya dipakai di naskah.\n")

xl = OUT / "REVISI_SOIC_HASIL_LENGKAP.xlsx"
with pd.ExcelWriter(xl, engine="openpyxl") as w:
    for name, df in sheets.items():
        df.to_excel(w, sheet_name=name[:31], index=False)
        df.to_csv(OUT / f"{name.replace(' ', '_')}.csv", index=False)

import shutil
zp = shutil.make_archive(str(BASE / "REVISI_SOIC_HASIL"), "zip", root_dir=OUT)
print(f"Workbook : {xl}")
print(f"Arsip    : {zp}")
print(f"Lembar   : {len(sheets)}")
print(f"Total waktu: {(time.time()-T0)/60:.0f} menit")
try:
    from google.colab import files
    files.download(zp)
except Exception:
    pass

print("""
================================================================================
SELESAI.

LANGKAH BERIKUTNYA, berurutan:
  1. Periksa lembar "Audit Konsistensi" di workbook. Kalau ada baris
     cocok=False, JANGAN pakai angkanya; hapus checkpoint tahap itu dan
     jalankan ulang tahap tersebut.
  2. Perbarui angka di kedua naskah (Inggris dan Indonesia) dari arsip ini,
     lalu verifikasi satu per satu. Blok 3 Tabel 4 (partisi empat-arah
     terkunci) sudah tidak diperlukan: Tahap 9 kini membandingkan encoder
     di-fine-tune dan beku pada lipatan yang sama, jadi laporkan itu sebagai
     tabel Tahap 9 untuk tiga titik akhir, bukan sebagai pembanding 12.
  3. Regresi logistik, SVM, random forest, bagging pohon, dan MLP kini di
     protokol utama (Tahap 3B), jadi pindahkan barisnya ke blok 1 Tabel 4 dan
     hapus peringatan ketidaksebandingan antar-blok untuk kelima baris itu.
  4. Untuk nilai p terkoreksi, kutip HANYA berkas
     Structural_Correlations.csv (lembar "Structural Correlations").
     Lembar Endpoint Correlations menyimpan p MENTAH dan tidak boleh
     dikutip sebagai hasil uji.

Yang MASIH perlu Anda kerjakan sendiri — tidak ada program yang bisa:
  - Seluruh gambar yang memuat data: dibangkitkan DI LUAR program ini dan
    masih memakai data lama. Setelah run ini, tabel 7.817 tetapi gambar
    belum. Kode plotnya ada di revisi_soic_01_posthoc.py dan
    revisi_soic_02_eksperimen.py
  - Gambar 1 (RoadMap.jpg): gambar ulang. Resolusinya ~130 dpi, angkanya
    masih 7.831 dan 7.820, langkah kurasinya belum menyebut pengeluaran
    stereoisomer, dan alurnya belum memuat Tahap 3B
  - Empat tanda \\TBD{} rujukan BAREKENG 2025, dan dua tanda untuk DOI
    Zenodo serta URL repositori
  - Response letter (WAJIB menurut editor)
  - Validasi eksperimental di laboratorium             (B12)

Sudah ADA di naskah, diperiksa 1 Nov 2026 — jangan dikerjakan ulang:
  - Reframing klaim jadi prioritisasi                  (B1, B2)
  - Interferensi asai flavonoid, dengan sitasi          (A8) paragraf
    Pohjala 2012 dan Kenda 2021, termasuk catatan bahwa kelima senyawa
    teratas justru diprediksi tidak aktif di kedua titik akhir reseptor
    androgen
  - Tox21 sebagai indikator mekanistik, bukan ukuran
    toksisitas tingkat organisme                        (B21) bagian sc:scope
  - Limitasi dan prioritas tindak lanjut eksperimental  (A11, B17)
  - Variabilitas asai dinyatakan TIDAK dapat diuji dari
    rilis Tox21 yang dipakai, berikut alasannya         (bagian \\rev{} §3.3)
  - Kajian pustaka termasuk ChemBERTa-2 dan MolPROP     (A9, A10, B20)
  - 2-3 sitasi karya SOIC (Watthaisong 2024, Ibrahim 2026, Maigari 2025)
  - Unggah kode ke GitHub/Zenodo (B10): berkas ini yang diunggah
================================================================================
""")
