#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
================================================================================
REVISI SOIC 4593 — PROGRAM LENGKAP
A Hybrid ChemBERTa-Morgan XGBoost Ensemble ... Blumea balsamifera
================================================================================

SATU program untuk seluruh poin reviewer yang bisa dijawab secara komputasional.
Berdiri sendiri: tidak bergantung pada state notebook lama. Jalankan di Colab
dengan runtime CPU (GPU hanya mempercepat TAHAP 2 dan opsional TAHAP 9).

--------------------------------------------------------------------------------
CARA PAKAI
--------------------------------------------------------------------------------
    1. Unggah "ini saja.xlsx" ke /content
    2. Atur STAGES di bawah (default: semua kecuali yang opsional)
    3. Jalankan. Tiap tahap menyimpan checkpoint, jadi aman diputus dan
       dilanjutkan: jalankan ulang, tahap yang sudah selesai akan dilewati.

PERKIRAAN WAKTU di Colab CPU (2 vCPU):
    Tahap 1-2 (data + fitur)            : 20-30 menit
    Tahap 3 (CV utama)                  : 2-4 jam
    Tahap 4 (ablasi + baseline)         : 2-3 jam
    Tahap 5 (model final + stabilitas)  : 40-60 menit
    Tahap 6 (uji kebocoran)             : 1,5-2,5 jam
    Tahap 7 (holdout kimia terjauh)     : 40-60 menit
    Tahap 8 (analisis post-hoc)         : 20-30 menit
    Tahap 9 (fine-tune ChemBERTa, opsi) : 1-2 jam di GPU, jangan di CPU

Set RUN_QUICK_TEST = True untuk uji jalan cepat pada 3 endpoint dan 1 repeat.

--------------------------------------------------------------------------------
PETA POIN REVIEWER
--------------------------------------------------------------------------------
Dijawab program ini:
    A1  uji signifikansi .................... Tahap 8
    A2  ChemBERTa beku vs fine-tune ......... Tahap 9 (opsional, perlu GPU)
    A3  strategi ensemble alternatif ........ Tahap 3
    A4  penanganan class imbalance .......... Tahap 4 (varian scale_pos_weight)
    A5  dampak eksklusi ..................... Tahap 1
    A6  arti dan CI skor prioritas .......... Tahap 5
    A7  karakteristik endpoint vs performa .. Tahap 8
    A12 baseline LR dan SVM ................. Tahap 4
    A13 validasi eksternal (proksi) ......... Tahap 7
    A14 metrik AD di luar Tanimoto .......... Tahap 8
    A15 sensitivitas pembobotan ............. Tahap 8
    A-Q4 generalisasi out-of-distribution ... Tahap 7 dan 8
    B3  justifikasi bobot ensemble .......... Tahap 3
    B4  hyperparameter per endpoint ......... Tahap 4 (nested CV terbatas)
    B5  diagnostik kalibrasi ................ Tahap 8
    B6  sensitivitas threshold .............. Tahap 8
    B7  pola missingness .................... Tahap 8
    B8  cutoff AD dan stratifikasi .......... Tahap 8
    B9  kebocoran analog .................... Tahap 1 dan 6
    B13 pembobotan skor prioritas ........... Tahap 8
    B14 ablasi komponen ..................... Tahap 4
    B16 stabilitas ranking .................. Tahap 5
    B18 pemisahan sumber variabilitas ....... Tahap 8
    B19 analisis false negative ............. Tahap 8

TIDAK bisa dijawab program apa pun — ini pekerjaan menulis dan eksperimen:
    A8/A-Q7 interferensi asai flavonoid ..... Discussion, perlu kajian pustaka
    A9, A10, B20 positioning dan pustaka .... Introduction dan Discussion
    A11, B17 limitasi dan rekomendasi ....... Conclusion
    B1, B2 reframing dan klaim kebaruan ..... Abstract dan Introduction
    B10 ketersediaan kode ................... unggah ke GitHub/Zenodo
    B12 validasi eksperimental .............. laboratorium
    B15 multi-task learning ................. future work, dijawab argumen
    B21 Tox21 sebagai proksi toksisitas ..... Methods, argumen
================================================================================
"""

import os, json, pickle, warnings, time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

warnings.filterwarnings("ignore")

# ==============================================================================
# KONFIGURASI
# ==============================================================================
STAGES = {
    1: True,   # data, kurasi (dilewati bila checkpoint ada)
    2: True,   # fitur     (dilewati bila checkpoint ada)
    3: False,   # CV utama + strategi kombinasi
    4: False,   # ablasi, baseline, imbalance, nested CV
    5: False,   # model final, ranking, stabilitas antar-seed, CI
    6: False,   # uji kebocoran analog
    7: False,   # holdout kimia terjauh (proksi validasi eksternal)
    8: False,   # seluruh analisis post-hoc
    9: False,  # fine-tune ChemBERTa — HANYA jalankan bila ada GPU
}

RUN_QUICK_TEST = False          # True = 3 endpoint, 1 repeat, bootstrap kecil

EXCEL_CANDIDATES = ["/content/ini saja.xlsx", "/content/ini saja(2).xlsx",
                    "/content/drive/MyDrive/ini saja.xlsx", "ini saja.xlsx"]
TOX21_URL = "https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/tox21.csv.gz"
CHEMBERTA_MODEL = "DeepChem/ChemBERTa-77M-MTR"

# PENTING: checkpoint disimpan di Google Drive, bukan di /content.
# /content terhapus setiap runtime Colab mati, sehingga seluruh tahap yang
# sudah selesai ikut hilang. Dengan Drive, program bisa dijalankan
# sepotong-sepotong lintas sesi: jalankan ulang dan ia lanjut dari tahap terakhir.
USE_DRIVE = True

if USE_DRIVE and Path("/content").exists():
    try:
        from google.colab import drive
        if not Path("/content/drive/MyDrive").exists():
            drive.mount("/content/drive")
        BASE = Path("/content/drive/MyDrive/revisi_soic")
        print("Checkpoint disimpan di Google Drive:", BASE)
    except Exception as _e:
        BASE = Path("/content/revisi_soic")
        print("Drive tidak tersedia, checkpoint lokal (HILANG bila runtime mati):", _e)
elif Path("/content").exists():
    BASE = Path("/content/revisi_soic")
else:
    BASE = Path("./revisi_soic")
CKPT, OUT, FIG = BASE / "checkpoints", BASE / "hasil", BASE / "hasil" / "figures"
for p in (CKPT, OUT, FIG):
    p.mkdir(parents=True, exist_ok=True)

TOX21_TASKS = ["NR-AR", "NR-AR-LBD", "NR-AhR", "NR-Aromatase", "NR-ER", "NR-ER-LBD",
               "NR-PPAR-gamma", "SR-ARE", "SR-ATAD5", "SR-HSE", "SR-MMP", "SR-p53"]
if RUN_QUICK_TEST:
    TOX21_TASKS = ["NR-AR", "SR-MMP", "NR-ER"]

SEED = 42
REPEAT_SEEDS = [42] if RUN_QUICK_TEST else [42, 73, 101]
N_SPLITS, INNER_SPLITS = 5, 5
N_BOOT = 200 if RUN_QUICK_TEST else 1000
CI = 0.95
FP_BITS, FP_RADIUS = 2048, 2
LEAKAGE_CUTOFFS = [0.9, 0.7]
AD_TANIMOTO_CUTOFF = 0.40

DESCRIPTOR_NAMES = ["MolWt", "MolLogP", "TPSA", "HBA", "HBD", "RotatableBonds",
                    "RingCount", "AromaticRings", "HeavyAtoms", "FractionCSP3", "QED",
                    "FormalCharge", "MolMR", "LabuteASA", "NumHeteroatoms",
                    "NumSaturatedRings"]


def save(name, obj):
    with open(CKPT / f"{name}.pkl", "wb") as f:
        pickle.dump(obj, f)


def load(name):
    p = CKPT / f"{name}.pkl"
    return pickle.load(open(p, "rb")) if p.exists() else None


def done(name):
    return (CKPT / f"{name}.pkl").exists()


def banner(txt):
    print("\n" + "=" * 78 + f"\n{txt}\n" + "=" * 78, flush=True)


T0 = time.time()


# ==============================================================================
# TAHAP 1 — DATA, KURASI, EKSKLUSI STEREO-AWARE                      [A5, B9]
# ==============================================================================
# PERBAIKAN PENTING terhadap pipeline lama. Eksklusi sebelumnya memakai
# canonical SMILES isomerik, sementara Morgan fingerprint dibuat tanpa
# useChirality. Akibatnya stereoisomer senyawa Blumea tetap tertinggal di
# data latih dengan fingerprint yang IDENTIK — kebocoran yang dilaporkan
# Reviewer B (poin 2.8). Di sini eksklusi dilakukan pada SMILES tanpa
# stereokimia, dan jumlah struktur tambahan yang terbuang dicatat.

if STAGES[1] and not done("s1_data"):
    banner("TAHAP 1 — data, kurasi, eksklusi stereo-aware")
    from rdkit import Chem, RDLogger
    from rdkit.Chem.Scaffolds import MurckoScaffold
    RDLogger.DisableLog("rdApp.*")

    def canon(s, iso=True):
        if pd.isna(s):
            return None
        m = Chem.MolFromSmiles(str(s).strip())
        return Chem.MolToSmiles(m, canonical=True, isomericSmiles=iso) if m else None

    def scaffold(s):
        m = Chem.MolFromSmiles(s)
        if m is None:
            return None
        sc = MurckoScaffold.MurckoScaffoldSmiles(mol=m, includeChirality=True)
        return sc if sc else f"ACYCLIC::{s}"

    def resolve(series):
        v = pd.to_numeric(series, errors="coerce").dropna().astype(int).unique()
        return float(v[0]) if len(v) == 1 else np.nan

    raw = pd.read_csv(TOX21_URL, compression="gzip")
    tox = raw[["smiles", *TOX21_TASKS]].copy()
    tox["canonical_smiles"] = [canon(x) for x in tox["smiles"]]
    n_invalid = int(tox["canonical_smiles"].isna().sum())
    tox = tox.dropna(subset=["canonical_smiles"])
    tox = tox.groupby("canonical_smiles", as_index=False).agg(
        {t: resolve for t in TOX21_TASKS})
    tox["flat_smiles"] = [canon(s, iso=False) for s in tox["canonical_smiles"]]
    tox["scaffold"] = tox["canonical_smiles"].map(scaffold)
    n_before = len(tox)

    xp = next((Path(p) for p in EXCEL_CANDIDATES if Path(p).exists()), None)
    if xp is None:
        raise FileNotFoundError("Letakkan 'ini saja.xlsx' di /content")
    braw = pd.read_excel(xp, sheet_name=0)
    braw["cs"] = braw["Canonical SMILES"].map(lambda s: canon(s))
    keep = [c for c in ["Skor Toksisitas", "computational toxicity priority"]
            if c in braw.columns]
    firstv = lambda s: s.dropna().iloc[0] if s.dropna().size else np.nan
    blumea = (braw.dropna(subset=["cs"]).groupby("cs", as_index=False)
              .agg({"Prediksi Senyawa": firstv, **{c: firstv for c in keep}})
              .rename(columns={"cs": "canonical_smiles",
                               "Prediksi Senyawa": "compound_name"}))
    blumea["flat_smiles"] = [canon(s, iso=False) for s in blumea["canonical_smiles"]]

    iso_set = set(blumea["canonical_smiles"])
    flat_set = set(blumea["flat_smiles"].dropna())

    mask_iso = tox["canonical_smiles"].isin(iso_set)
    mask_flat = tox["flat_smiles"].isin(flat_set)
    mask_stereo_only = mask_flat & ~mask_iso          # yang DULU lolos

    name_by_flat = {}
    for _, r in blumea.iterrows():
        if r["flat_smiles"]:
            name_by_flat.setdefault(r["flat_smiles"], r["compound_name"])

    audit_iso = tox[mask_iso].assign(
        blumea_compound=tox.loc[mask_iso, "flat_smiles"].map(name_by_flat),
        exclusion_reason="identical isomeric SMILES")
    audit_stereo = tox[mask_stereo_only].assign(
        blumea_compound=tox.loc[mask_stereo_only, "flat_smiles"].map(name_by_flat),
        exclusion_reason="stereoisomer / non-stereo duplicate (NEW)")
    overlap_audit = pd.concat([audit_iso, audit_stereo], ignore_index=True)

    tox = tox[~mask_flat].reset_index(drop=True)
    assert not set(tox["flat_smiles"]) & flat_set

    s1 = dict(tox=tox, blumea=blumea, overlap_audit=overlap_audit,
              n_invalid=n_invalid, n_before=n_before, n_after=len(tox),
              n_removed_iso=int(mask_iso.sum()),
              n_removed_stereo_only=int(mask_stereo_only.sum()))
    save("s1_data", s1)
    print(f"Tox21 valid unik           : {n_before}")
    print(f"Dibuang (SMILES identik)   : {s1['n_removed_iso']}")
    print(f"Dibuang (stereoisomer BARU): {s1['n_removed_stereo_only']}  <-- perbaikan")
    print(f"Tox21 dipakai              : {len(tox)}  "
          f"({100*(n_before-len(tox))/n_before:.3f}% dibuang)")
    print(f"Senyawa Blumea unik        : {len(blumea)}")
    overlap_audit.to_csv(OUT / "01_audit_eksklusi.csv", index=False)

s1 = load("s1_data")
tox, blumea = s1["tox"], s1["blumea"]


# ==============================================================================
# TAHAP 2 — FITUR
# ==============================================================================
if STAGES[2] and not done("s2_features"):
    banner("TAHAP 2 — fitur Morgan, RDKit, ChemBERTa")
    from rdkit import Chem, DataStructs
    from rdkit.Chem import AllChem, Descriptors, Crippen, Lipinski, rdMolDescriptors, QED

    all_smiles = list(dict.fromkeys(
        tox["canonical_smiles"].tolist() + blumea["canonical_smiles"].tolist()))
    gen = AllChem.GetMorganGenerator(radius=FP_RADIUS, fpSize=FP_BITS)
    fps, descs = [], []
    for i, smi in enumerate(all_smiles):
        if i % 2000 == 0:
            print(f"  fitur {i}/{len(all_smiles)}", flush=True)
        m = Chem.MolFromSmiles(smi)
        a = np.zeros((FP_BITS,), dtype=np.uint8)
        DataStructs.ConvertToNumpyArray(gen.GetFingerprint(m), a)
        fps.append(a)
        descs.append([Descriptors.MolWt(m), Crippen.MolLogP(m),
                      rdMolDescriptors.CalcTPSA(m), Lipinski.NumHAcceptors(m),
                      Lipinski.NumHDonors(m), Lipinski.NumRotatableBonds(m),
                      Lipinski.RingCount(m), Lipinski.NumAromaticRings(m),
                      Lipinski.HeavyAtomCount(m), rdMolDescriptors.CalcFractionCSP3(m),
                      QED.qed(m), Chem.GetFormalCharge(m), Crippen.MolMR(m),
                      rdMolDescriptors.CalcLabuteASA(m), Lipinski.NumHeteroatoms(m),
                      Lipinski.NumSaturatedRings(m)])
    fp_all = np.asarray(fps, dtype=np.float32)
    desc_all = np.asarray(descs, dtype=np.float32)

    import torch
    from transformers import AutoTokenizer, AutoModel
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("  ChemBERTa di", dev, flush=True)
    tok = AutoTokenizer.from_pretrained(CHEMBERTA_MODEL)
    enc = AutoModel.from_pretrained(CHEMBERTA_MODEL).to(dev).eval()
    embs = []
    for i in range(0, len(all_smiles), 64):
        if i % 1280 == 0:
            print(f"  embedding {i}/{len(all_smiles)}", flush=True)
        t = tok(all_smiles[i:i + 64], padding=True, truncation=True,
                max_length=256, return_tensors="pt")
        t = {k: v.to(dev) for k, v in t.items()}
        with torch.inference_mode():
            h = enc(**t).last_hidden_state
            m = t["attention_mask"].unsqueeze(-1).expand(h.size()).float()
            embs.append(((h * m).sum(1) / m.sum(1).clamp(min=1e-9)).cpu().numpy())
    chemberta_all = np.vstack(embs).astype(np.float32)
    del enc

    idx = {s: i for i, s in enumerate(all_smiles)}
    ti = np.array([idx[s] for s in tox["canonical_smiles"]])
    bi = np.array([idx[s] for s in blumea["canonical_smiles"]])
    np.savez_compressed(CKPT / "features.npz", fp=fp_all, desc=desc_all,
                        emb=chemberta_all, ti=ti, bi=bi)
    save("s2_features", {"n": len(all_smiles)})
    print("  Morgan", fp_all.shape, "| RDKit", desc_all.shape,
          "| ChemBERTa", chemberta_all.shape)

_f = np.load(CKPT / "features.npz")
fp_all, desc_all, emb_all = _f["fp"], _f["desc"], _f["emb"]
ti, bi = _f["ti"], _f["bi"]

# fp_all/desc_all/emb_all diindeks pada DAFTAR SMILES GABUNGAN, bukan pada
# baris Tox21. Jangan pernah memakainya langsung dengan mask sepanjang len(tox).
# Selalu pakai matriks ber-sufiks _t (Tox21) atau _b (Blumea) di bawah ini.
fp_t, desc_t, emb_t = fp_all[ti], desc_all[ti], emb_all[ti]
fp_b, desc_b, emb_b = fp_all[bi], desc_all[bi], emb_all[bi]

X_tox_m = np.hstack([fp_t, desc_t])
X_tox_c = np.hstack([emb_t, desc_t])
X_blu_m = np.hstack([fp_b, desc_b])
X_blu_c = np.hstack([emb_b, desc_b])

assert len(X_tox_m) == len(tox), (len(X_tox_m), len(tox))
assert len(X_blu_m) == len(blumea), (len(X_blu_m), len(blumea))


# ==============================================================================
# FUNGSI BERSAMA
# ==============================================================================
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (roc_auc_score, average_precision_score,
                             balanced_accuracy_score, matthews_corrcoef,
                             confusion_matrix, roc_curve, brier_score_loss,
                             accuracy_score, f1_score, precision_score, recall_score)
from xgboost import XGBClassifier

XGB_DEV = "cpu"
try:
    import torch as _t
    if _t.cuda.is_available():
        XGB_DEV = "cuda"
except Exception:
    pass


def make_xgb(seed=SEED, **kw):
    p = dict(n_estimators=350, max_depth=4, learning_rate=0.04, min_child_weight=2,
             subsample=0.80, colsample_bytree=0.70, reg_alpha=0.10, reg_lambda=2.0,
             objective="binary:logistic", eval_metric="logloss", tree_method="hist",
             device=XGB_DEV, random_state=seed, n_jobs=-1)
    p.update(kw)
    return XGBClassifier(**p)


def bal_w(y):
    y = np.asarray(y).astype(int)
    c = np.bincount(y, minlength=2)
    return np.array([len(y) / (2 * max(c[v], 1)) for v in y], dtype=float)


def logit(p):
    p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p)).reshape(-1, 1)


def platt(raw, y):
    m = LogisticRegression(C=1.0, solver="lbfgs", max_iter=2000)
    m.fit(logit(raw), np.asarray(y).astype(int))
    return m


def apply_cal(c, raw):
    return c.predict_proba(logit(raw))[:, 1]


def youden(y, p):
    y = np.asarray(y).astype(int)
    fpr, tpr, th = roc_curve(y, p)
    ok = np.isfinite(th)
    fpr, tpr, th = fpr[ok], tpr[ok], th[ok]
    j = tpr + (1 - fpr) - 1
    cand = np.where(np.isclose(j, j.max()))[0]
    b = cand[np.argmin(th[cand])]
    return float(th[b])


def splits(y, g, n, seed):
    y = np.asarray(y).astype(int); g = np.asarray(g)
    k = min(n, int(np.bincount(y).min()), len(np.unique(g)))
    if k < 3:
        raise ValueError("data tidak cukup")
    for off in range(50000):
        cv = StratifiedGroupKFold(n_splits=k, shuffle=True, random_state=int(seed + off))
        sp = list(cv.split(np.zeros(len(y)), y, g))
        if all(len(np.unique(y[a])) == 2 and len(np.unique(y[b])) == 2 for a, b in sp):
            return sp
    raise RuntimeError("split gagal")


def fit_fold(Xtr, ytr, Xte, bi_, ci_, seed, est="xgb", **kw):
    """Latih di base-training, kalibrasi Platt di calibration subset."""
    imp = SimpleImputer(strategy="median")
    Xb, Xc, Xt = imp.fit_transform(Xtr[bi_]), imp.transform(Xtr[ci_]), imp.transform(Xte)
    yb = ytr[bi_]
    if est == "xgb":
        m = make_xgb(seed, **kw)
        m.fit(Xb, yb, sample_weight=None if kw.get("scale_pos_weight") else bal_w(yb),
              verbose=False)
        rc, rt = m.predict_proba(Xc)[:, 1], m.predict_proba(Xt)[:, 1]
    else:
        sc = StandardScaler(with_mean=False)
        Xb2, Xc2, Xt2 = sc.fit_transform(Xb), sc.transform(Xc), sc.transform(Xt)
        if est == "logreg":
            m = LogisticRegression(C=1.0, max_iter=3000, solver="liblinear",
                                   class_weight="balanced", random_state=seed)
        else:
            m = CalibratedClassifierCV(
                LinearSVC(C=0.1, class_weight="balanced", max_iter=5000,
                          dual="auto", random_state=seed), method="sigmoid", cv=3)
        m.fit(Xb2, yb)
        rc, rt = m.predict_proba(Xc2)[:, 1], m.predict_proba(Xt2)[:, 1]
    cal = platt(rc, ytr[ci_])
    return apply_cal(cal, rt), apply_cal(cal, rc), rt


def metrics(y, p, pred):
    y = np.asarray(y).astype(int); pred = np.asarray(pred).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return dict(accuracy=accuracy_score(y, pred),
                balanced_accuracy=balanced_accuracy_score(y, pred),
                precision=precision_score(y, pred, zero_division=0),
                sensitivity=recall_score(y, pred, zero_division=0),
                specificity=tn / (tn + fp) if (tn + fp) else np.nan,
                f1=f1_score(y, pred, zero_division=0),
                mcc=matthews_corrcoef(y, pred), roc_auc=roc_auc_score(y, p),
                average_precision=average_precision_score(y, p),
                brier=brier_score_loss(y, p), tn=tn, fp=fp, fn=fn, tp=tp)


def endpoint_data(task):
    m = tox[task].notna().to_numpy()
    return (m, tox.loc[m, task].astype(int).to_numpy(),
            tox.loc[m, "scaffold"].astype(str).to_numpy())


BRANCHES = [("Morgan–XGBoost", X_tox_m, X_blu_m), ("ChemBERTa–XGBoost", X_tox_c, X_blu_c)]



# ==============================================================================
# TAHAP B — GARIS DASAR DI PROTOKOL UTAMA (3 x 5 lipatan scaffold)
#
#  Menjalankan regresi logistik, SVM linear, dan random forest (bagging)
#  di bawah protokol yang IDENTIK dengan Tabel 4 blok 1: tiga pengulangan,
#  benih 42/73/101, pembelahan scaffold yang sama, kalibrasi Platt pada
#  subhimpunan kalibrasi terpisah-scaffold, ambang Youden.
#
#  Tidak menyentuh checkpoint mana pun yang sudah ada.
# ==============================================================================
from sklearn.ensemble import RandomForestClassifier

_fit_fold_asli = fit_fold

def fit_fold(Xtr, ytr, Xte, bi_, ci_, seed, est="xgb", **kw):
    """Perluasan: menambah est='rf'. Selain itu memanggil versi asli."""
    if est != "rf":
        return _fit_fold_asli(Xtr, ytr, Xte, bi_, ci_, seed, est=est, **kw)
    imp = SimpleImputer(strategy="median")
    Xb = imp.fit_transform(Xtr[bi_]); Xc = imp.transform(Xtr[ci_]); Xt = imp.transform(Xte)
    yb = ytr[bi_]
    m = RandomForestClassifier(n_estimators=400, max_depth=None, min_samples_leaf=2,
                               max_features="sqrt", class_weight="balanced_subsample",
                               n_jobs=-1, random_state=int(seed))
    m.fit(Xb, yb)
    rc, rt = m.predict_proba(Xc)[:, 1], m.predict_proba(Xt)[:, 1]
    cal = platt(rc, ytr[ci_])
    return apply_cal(cal, rt), apply_cal(cal, rc), rt


GARIS_DASAR = [("Logistic regression", "logreg"),
               ("Linear SVM",          "svm"),
               ("Random forest (bagging)", "rf")]

banner("TAHAP B — garis dasar di protokol utama")
oof_rows, met_rows = [], []

for t_i, task in enumerate(TOX21_TASKS):
    print(f"  [{t_i+1}/{len(TOX21_TASKS)}] {task}  "
          f"({(time.time()-T0)/60:.0f} mnt)", flush=True)
    mask, y, g = endpoint_data(task)
    rows_idx = np.where(mask)[0]
    X = X_tox_m[mask]
    acc = {nm: [] for nm, _ in GARIS_DASAR}
    accthr = {nm: [] for nm, _ in GARIS_DASAR}

    for r_i, rs in enumerate(REPEAT_SEEDS, 1):
        P = {nm: np.full(len(y), np.nan) for nm, _ in GARIS_DASAR}
        T = {nm: np.full(len(y), np.nan) for nm, _ in GARIS_DASAR}
        for fold, (tr, te) in enumerate(splits(y, g, N_SPLITS, rs), 1):
            isp = splits(y[tr], g[tr], INNER_SPLITS, rs + fold + 10000 * t_i)
            b_, c_ = isp[0]
            ycal = y[tr][c_]
            for m_i, (nm, est) in enumerate(GARIS_DASAR):
                pt, pc, _ = fit_fold(X[tr], y[tr], X[te], b_, c_,
                                     rs + fold + 100 * m_i + 10000 * t_i, est=est)
                P[nm][te] = pt
                T[nm][te] = youden(ycal, pc)

        for nm, _ in GARIS_DASAR:
            if np.isnan(P[nm]).any():
                continue
            acc[nm].append(P[nm]); accthr[nm].append(T[nm])
            pred = (P[nm] >= T[nm]).astype(int)
            met_rows.append(dict(endpoint=task, model=nm, repeat=r_i,
                                 **metrics(y, P[nm], pred)))

    for nm, _ in GARIS_DASAR:
        if not acc[nm]:
            continue
        p = np.mean(np.vstack(acc[nm]), 0)
        th = np.median(np.vstack(accthr[nm]), 0)
        pred = (p >= th).astype(int)
        for li, oi in enumerate(rows_idx):
            oof_rows.append(dict(endpoint=task, model=nm, tox21_row=int(oi),
                                 scaffold=g[li], y_true=int(y[li]),
                                 probability=float(p[li]),
                                 applied_threshold=float(th[li]),
                                 prediction=int(pred[li])))

oof = pd.DataFrame(oof_rows)
oof.to_csv(OUT / "baseline_utama_oof.csv.gz", index=False)
pd.DataFrame(met_rows).to_csv(OUT / "baseline_utama_per_repeat.csv", index=False)

# ---- ringkasan dengan estimator yang SAMA dengan blok 1 (pooled per endpoint)
ring = []
for (nm, ep), gg in oof.groupby(["model", "endpoint"]):
    ring.append(dict(model=nm, endpoint=ep, **metrics(gg.y_true.values,
                                                      gg.probability.values,
                                                      gg.prediction.values)))
R = pd.DataFrame(ring)
R.to_csv(OUT / "baseline_utama_per_endpoint.csv", index=False)

kol = ["balanced_accuracy", "mcc", "roc_auc", "average_precision", "brier"]
S = R.groupby("model")[kol].agg(["mean", "std"])
S.to_csv(OUT / "baseline_utama_ringkasan.csv")

print("\n=================== HASIL UNTUK BLOK 1 TABEL 4 ===================")
for nm in S.index:
    r = S.loc[nm]
    print(f"{nm:26s} " + "  ".join(
        f"{k.split('_')[0][:4]} {r[(k,'mean')]:.3f}+-{r[(k,'std')]:.3f}" for k in kol))
print("\ntersimpan di", OUT)
print("  baseline_utama_ringkasan.csv   <- angka untuk naskah")
print("  baseline_utama_per_endpoint.csv")
print("  baseline_utama_per_repeat.csv")
print("  baseline_utama_oof.csv.gz")
