import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.family":"serif","font.size":8})

import sys
FIGH=float(sys.argv[1]) if len(sys.argv)>1 else 9.8
fig,ax = plt.subplots(figsize=(6.9*1.42,FIGH)); ax.axis("off")
INK="#1b1b1b"; LINE="#9aa3ab"; BLUE="#2c5f8a"; RED="#a8402f"; GREY="#5a5a5a"
F0="#f5f7f9"; FB="#e9f1f8"; FR="#fcefec"
X0,XW = 1.0,98.0; CX = X0+XW/2
PTU=5.0*1.42                          # pt per satuan y, DIKUNCI
YHI=101.5; YLO=YHI-FIGH*72.0/PTU
BODY=9.37; LH=BODY*1.78/PTU          # tinggi baris dalam satuan y

def hdr(n,t,y):
    ax.text(X0,y,str(n),ha="left",va="center",fontsize=13.49,color=BLUE,weight="bold")
    ax.text(X0+3.6,y,t,ha="left",va="center",fontsize=10.51,color=BLUE,weight="bold")

def box(x,ytop,w,txt,fill=F0,fs=BODY,bold=None,ha="center",pad=4.2):
    n=txt.count("\n")+1+(2 if bold else 0)
    h=n*LH+pad
    ax.add_patch(FancyBboxPatch((x,ytop-h),w,h,boxstyle="round,pad=0,rounding_size=1.1",
                                fc=fill,ec=LINE,lw=.75,zorder=2))
    cx = x+w/2 if ha=="center" else x+2.2
    if bold:
        ax.text(cx,ytop-pad/2,bold,ha=ha,va="top",fontsize=fs+0.85,color=INK,weight="bold",zorder=3)
        ax.text(cx,ytop-pad/2-2*LH,txt,ha=ha,va="top",fontsize=fs,color=INK,
                zorder=3,linespacing=1.63)
    else:
        ax.text(cx,ytop-h/2,txt,ha=ha,va="center",fontsize=fs,color=INK,zorder=3,linespacing=1.63)
    return ytop-h

def arr(x0,y0,x1,y1,head=True,c=LINE):
    ax.add_patch(FancyArrowPatch((x0,y0),(x1,y1),arrowstyle="-|>" if head else "-",
                                 mutation_scale=7,lw=.9,color=c,zorder=1,shrinkA=0,shrinkB=0))

y=100.0
# ================= 1. Curation =================
hdr(1,"Curation",y); y-=3.4
bl=box(X0,y,47,"Tox21 release, 12 endpoints\n7,831 structure entries",fill=FB)
br=box(X0+51,y,47,"$\\it{Blumea\\ balsamifera}$\n129 compound records",fill=FR)
arr(X0+23.5,bl,X0+23.5,bl-1.8)
fy=bl-3.3
for s,n in [("$-$  8 invalid or unparsable","7,823"),
            ("$-$  6 overlapping the application set","7,817"),
            ("       3 identical on isomeric SMILES; 3 stereoisomers","")]:
    ax.text(X0+1.8,fy,s,ha="left",va="center",fontsize=8.66,color=RED)
    ax.text(X0+46.0,fy,n,ha="right",va="center",fontsize=9.66,color=INK,weight="bold")
    ax.plot([X0+1.2,X0+45.8],[fy-1.25,fy-1.25],color="#dde3e8",lw=.55,zorder=0)
    fy-=2.5
cur=box(X0,fy+0.9,47,"7,817 curated structures  (development set)",fill=FB)
ax.text(X0+74.5,br-1.7,"SMILES validated, duplicates merged",ha="center",va="center",
        fontsize=8.95,color=GREY)
arr(X0+74.5,br-3.3,X0+74.5,br-5.0)
app=box(X0+51,br-5.0,47,"31 unique compounds\nunlabelled application set",fill=FR)
ax.text(X0+74.5,app-1.9,"carried forward to stage 6",ha="center",va="center",
        fontsize=8.95,color=GREY,style="italic")

# ================= 2. Feature construction =================
y=min(cur,app-3.8)-4.2
hdr(2,"Feature construction",y); y-=3.4
arr(CX,cur,CX,y+1.6,head=False)
arr(CX,y+1.6,X0+23.5,y+1.6,head=False); arr(CX,y+1.6,X0+74.5,y+1.6,head=False)
arr(X0+23.5,y+1.6,X0+23.5,y); arr(X0+74.5,y+1.6,X0+74.5,y)
a=box(X0,y,47,"Morgan fingerprint\n2,048 bits, radius 2, no chirality\n$+$  16 RDKit descriptors",
      bold="Branch A",ha="left")
b=box(X0+51,y,47,"Frozen ChemBERTa encoder\n384 embedding features\n$+$  16 RDKit descriptors",
      bold="Branch B",ha="left")

# ================= 3. Partitioning =================
y=a-4.2; hdr(3,"Partitioning",y); y-=3.4
arr(X0+23.5,a,X0+23.5,a-2.1,head=False); arr(X0+74.5,b,X0+74.5,b-2.1,head=False)
arr(X0+23.5,a-2.1,X0+74.5,a-2.1,head=False); arr(CX,a-2.1,CX,y)
p=box(X0,y,XW,
 "Per endpoint, unlabelled structures are dropped and the labelled subset is partitioned by three\n"
 "repetitions of five-fold Bemis--Murcko scaffold cross-validation (seeds 42, 73, 101): 15 outer folds.\n"
 "Within each outer fold the training data are split again by scaffold into base training and calibration.")

# ================= 4. Fitting, calibration, thresholds =================
y=p-4.2; hdr(4,"Fitting, calibration, and thresholds",y); y-=3.4
arr(CX,p,CX,y)
f=box(X0,y,XW,
 "XGBoost fitted per branch and endpoint on the base training set, with median imputation and\n"
 "class weighting; hyperparameters fixed across endpoints (max_depth 4, learning_rate 0.04)\n"
 "\n"
 "Platt scaling on the calibration set   $\\rightarrow$   equal-weight soft voting across branches\n"
 "$\\rightarrow$   endpoint-specific Youden thresholds",fill=FB)

# ================= 5. Evaluation =================
y=f-4.2; hdr(5,"Evaluation",y); y-=3.4
arr(CX,f,CX,y)
e=box(X0,y,XW,
 "Locked models, calibrators and thresholds are scored on the untouched outer test folds\n"
 "\n"
 "Significance   paired stratified bootstrap with Holm--Bonferroni  ·  DeLong  ·  Stouffer\n"
 "Design probes   ablation  ·  simpler learners on identical folds  ·  alternative combination rules\n"
 "Robustness   close-analogue exclusion  ·  distant-scaffold holdout  ·  random label masking\n"
 "\n"
 "Ensemble   ROC-AUC 0.793 $\\pm$ 0.050      average precision 0.386 $\\pm$ 0.126")

# ================= 6. Application and bounding =================
y=e-4.2; hdr(6,"Application and bounding",y); y-=3.4
arr(CX,e,CX,y)
g=box(X0,y,XW,
 "Final per-branch models are fitted per endpoint, applied to the 31 application structures, averaged\n"
 "over repetitions and combined by soft voting, giving calibrated endpoint probabilities, activity calls\n"
 "and a multi-endpoint priority score\n"
 "\n"
 "Applicability domain   maximum Tanimoto to the curated Tox21 structures, explicit reliability cutoff,\n"
 "with leverage and distance-to-model as complements\n"
 "Ranking stability   across resampling seeds and across alternative endpoint weighting schemes",
 fill=FR)
ax.text(X0+XW,g-2.6,
 "Output: prioritized hypotheses for experimental follow-up, not validated activity predictions",
 ha="right",va="center",fontsize=9.09,color=GREY,style="italic")

ax.set_xlim(0,100); ax.set_ylim(YLO,YHI)
print("TINGGI_PERLU", round((YHI-(g-3.2))*PTU/72.0,3))
fig.savefig("RoadMap.pdf",bbox_inches="tight",pad_inches=0.05)
fig.savefig("RoadMap_preview.png",dpi=150,bbox_inches="tight",pad_inches=0.05)
print("bawah =",round(g,1))
